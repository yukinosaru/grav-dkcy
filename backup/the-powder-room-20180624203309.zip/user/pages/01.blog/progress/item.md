---
# http://learn.getgrav.org/content/headers
title: Progress!
slug: progress
# menu: Progress!
date: 14-08-2006
published: true
publish_date: 14-08-2006
# unpublish_date: 14-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**14th August 2006, 20:30**  
*Alpine Resort*

Well, another week, another training group. This week I’m with Claire, Nicole and Chelsea with Neil as our trainer (Pete joined us after lunch). It’s the first time I’ve ridden with Neil and I’m really enjoying it. I feel like I made a bit of a breakthrough with the completion of my heelside turns (which is where my big problem is) – it’s not perfect, but I know what it needs to feel like, so it’s just a question of practice.

Feeling a bit more confident about Stage 1 now, still a lot to do, but getting there. We’ve got to do some lesson planning tonight and then tomorrow we’ll have a proper slot to practice teaching. Looking forward to it, cos it’s what it’s all about.