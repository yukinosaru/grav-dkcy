---
# http://learn.getgrav.org/content/headers
title: Why?
slug: why
# menu: Why?
date: 19-12-2008
published: true
publish_date: 19-12-2008
# unpublish_date: 19-12-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,lebenskrankheit,synchronicity,japan,lebenskrankheit,synchronicity]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

 ![Standing in a river](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/img_5137-133x200.jpg "Standing in the river") Standing in a river 

I suppose I should explain this whole Japan thing really. Having been back in the UK for 18 months, trying to lead a ‘normal’ life, I finally had enough of office life, for a whole host of reasons. One way to sum it up is that I feel out of sync with the conventional workplace. A square peg in a grid of round holes. Stifled. But the most simple explanation is that it was making me miserable. Deeply so. So I’m leaving that life, sort of. I am torn between two worlds – one of trying to make a difference, change the world or whatever; the other about following my heart and seeking personal fulfillment. Is it possible to find a balance?

For me, the only course of action was to do something that makes my heart sing and keep open to opportunities. So I decided to go back to the mountains, shoved some proverbial career irons in the fire and let life take its course. Having applied late, I wasn’t very hopeful – then I got offered not one, but two jobs in Japan. I had one of those life moments where everything just falls into place to make something happen. Within 2 weeks, I had a job, booked my flight, let my flat out and got my visa. Fate? Wu wei wu? Chance? Does it matter – I’m off to a land with an average of 15m of snow each season! A land of bonsai, sushi, origami, cherry blossoms – all things I love – and finally getting the motivation to learn the language. Rock on. Sugoi desu ne?

What happens after the season? Who knows, we’ll see what the winds bring me, all I know is that I feel like I’m back on the right path for me, wherever it may lead.