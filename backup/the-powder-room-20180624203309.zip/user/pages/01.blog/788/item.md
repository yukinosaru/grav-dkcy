---
# http://learn.getgrav.org/content/headers
title: Ski-tastic
slug: 788
# menu: Ski-tastic
date: 02-03-2009
published: true
publish_date: 02-03-2009
# unpublish_date: 02-03-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [dailylife,instructing,japan,dailylife,instructing,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

[![Me pointing](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/pointing-145x200.jpg "Me pointing")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/pointing.jpg)Had a great day today, I’ve been teaching a nice Aussie lady, Jasmine, to ski for a couple of days, taking her from first timer and now she’s wedge christie turning, so I’m pretty pleased. We were joined today by another Aussie, Lisa, who is equally as enjoyable to ski with and have generally had a great day skiing around and working on their turns. I’ve found it really helpful for my skiing too as it’s made me focus on more basic things and refine my free-skiing. I’ve not taught a snowboard lesson for quite a while now and whilst I’m a little annoyed about that, I’ve also been really enjoying teaching skiing and finding it very rewarding. I think the fact that I’ve passed my exam also gives me a stronger sense of confidence in my knowledge and ability. I get on with all my guests, but there are just some times when you click with them and it feels like skiing with friends. I guess what I’ve really enjoyed about skiing with Jasmine and Lisa is that I feel comfortable in what I’m doing and much more able to be creative with my exercises and lessons – although I’ve taught skiing for a long time, it just feels like I’m doing a good job (on a par with my snowboard instruction), which is very satisfying (although I’ll have to leave it to them to pass judgement on whether that’s the truth!!)