---
# http://learn.getgrav.org/content/headers
title: Macchiato
slug: macchiato
# menu: Macchiato
date: 20-01-2017
published: true
publish_date: 20-01-2017
# unpublish_date: 20-01-2017
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 0
taxonomy:
    migration-status: review
    category: [Food glorious food]
    tag: [coffee,food hack,coffee,food hack]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---
  One of the most unexpected things about living in Addis Ababa was the coffee culture, specifically the prevalence of macchiatos (macchiati?). Since leaving, I’ve really missed it so I thought I’d have a go at making my own. Turns out it’s surprisingly achievable with a bit of creativity.![](http://www.dkcy.com/images/blog_20170120_01.jpg)

 You’ll need a microwave-proof bottle or jar with a lid – my weapon of choice is a baby milk bottle. I use about 30ml of whole milk, use more or less depending on your tastes (first image). Put the lid on and shake it vigorously until the milk is frothy and has doubled in volume – around a minute or two (second image). Tada! Now, this foam isn’t stable and will collapse if you leave it – so we need to fix it. Simply put it in the microwave for 15 seconds – the heat is enough to stabilise the foam (3rd and 4th image).![](http://www.dkcy.com/images/blog_20170120_02.jpg)

 Make your coffee however you want – I use a Moka stovetop espresso maker. Pour it into a suitable cup, add sugar, then add some of the liquid milk and spoon over the foam.

I’m going to try out some latte art next and see if it’s possible to do with this makeshift method!