---
# http://learn.getgrav.org/content/headers
title: Finance schminance
slug: 
# menu: Finance schminance
date: 29-01-2014
published: false
publish_date: 29-01-2014
# unpublish_date: 29-01-2014
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [አዲስቀን (Addis/New Days)]
    tag: [Ethiopia,finance,green growth,reality check,Ethiopia,finance,green growth,reality check]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Went to a workshop in the political economy of CRGE in Ethiopia.  
 Power and incentives missing  
 Finance and policy focus on climate change. But other sources of finance that achieve the same thing.  
 Other drivers are more powerful and overarching. E.g. growth or meeting GTP targets.