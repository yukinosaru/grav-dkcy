---
# http://learn.getgrav.org/content/headers
title: Jay
slug: jay
# menu: Jay
date: 01-11-2006
published: true
publish_date: 01-11-2006
# unpublish_date: 01-11-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**2nd Novembe 2006, 11.56am**  
*Internet Cafe in Windy Wellington*

Felt compelled to blog this. So we stayed at a lovely hostel in Picton called Sequoia, camping in their car park for a mere $14. Anyway, the next morning, we were packing up to go and a guy comes over and asks when I’m selling Doris. So we had a chat and swapped numbers so I can call him when we’re in Auckland.

Being the inquisitive type, I asked about what he did and what he’s up to – turns out he has cancer and only a matter of a few months to live. He’s just finished doing up a BMW for his mate’s 9 year old daughter and is just buzzing around New Zealand doing a few things he hadn’t got round to. So we hung out in the sun and chatted for a bit, he even offered us the use of his boat in the Bay of Islands.

Jay was inspiring, saddening, generous and funny and I’m sure there’s some profound meaning and message in all of this, but I’ll leave that to you – all I know is that I’m glad I met him.