---
# http://learn.getgrav.org/content/headers
title: Day 2
slug: day-2
# menu: Day 2
date: 10-01-2009
published: true
publish_date: 10-01-2009
# unpublish_date: 10-01-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Sitting on my bed, with my knee strapped up and in ice

![View from my room. Check out how deep the snow is on the left.](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/dsc00423-200x150.jpg "View from room")View from my room. Check out how deep the snow is on the left.



Went out to Abucha with Francis last night and had proper sukiyaki – was nice, if a little pricey (2100 yen), was supposed to meet James (who I worked with at WP) but I couldn’t find the bar, so I came back. Met two random Japanese guys who jibbered away at me – all I could say was ‘wakarimasen’ (I don’t understand), ‘gomenasai, watashi wa nihongo o hanasimasen’ (sorry, I don’t speak Japanese), to which they smiled and acknowledged, then carried on chatting to me! Unitas is a little way out of the main town, but it’s easy to get around here, lots of free shuttle buses and if needs be, it’s only about 10 minutes to walk back from town. Got back to find our heating had packed in! Not good. So a freezing night’s sleep (although the beds are actually very warm).

![My room! Mine's the bed on the left](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/dsc00425-200x150.jpg "My room")My room! Mine's the bed on the left



Woke up today and struggled to get out of my nice warm bed. But I did, pulled back the curtains to see that the forecast snow had arrived and it was gently snowing. It had only just started, so I pottered over for breakfast and chatted to people. Kurokawa, our friendly repairman, came and sorted out the heating and I headed to the mountain. Met Tom, the operations manager at the ski school who was very friendly and professional. Then went for a ride – there was about an inch on the ground and it was coming down thick and fast now.

![Snow clearing: Niseko-style. You can see how deep it is on the sides of the path.](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/dsc00427-200x150.jpg "Snow clearing")Snow clearing: Niseko-style. You can see how deep it is on the sides of the path.



My knee had started to hurt a little yesterday, so I took it easy today, but after a couple of runs, it was killing me, so I stopped and decided to rest it today. I’ve had probs with it before, and I guess cos my muscles aren’t up to strength yet, it’s putting more strain on my ligaments, I’m gonna strap it and take it easy. Hopefully it’s nothing major, but it’s a worrying start.  
 So I’m back here, having found a van that sold gyu-don (bowl of rice with beef and pickles) for a mere 650 yen (about a fiver). Resting today, then it’s someone’s birthday so people are going to karaoke tonight – I haven’t been invited yet, but will probably just gatecrash! People haven’t been quite as welcoming as I’d expected or experienced elsewhere – but I guess I’ve just gotta make the effort though.