---
# http://learn.getgrav.org/content/headers
title: Lumbini
slug: lumbini
# menu: Lumbini
date: 10-11-2008
published: true
publish_date: 10-11-2008
# unpublish_date: 10-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Sal tree](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081110_46711-133x200.jpg "Sal tree")Sal tree



![Turtles peeking out](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081110_46481-133x200.jpg "Turtles peeking")Turtles peeking out



We start with a pleasant, if protracted breakfast. A hippy guy nearby is playing the bansuri and all is peaceful. I silently vow to learn it and wander Kung Fu style finding nice spots to play.

![Monks in Lumbini](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081110_46081-133x200.jpg "Monks in Lumbini")Monks in Lumbini



Beautiful morning spent at the Mayadevi temple where Siddharta was born. We find the Sal tree that has become a shrine.

Several monks sit guard, prayer flags fluttering and butterflies drifting past. Propping ourselves on a meditation platform, we watch the world go by. I peek at the turtles in the pond and they peek back. Playful chipmunks race around chasing each other before pausing to namaste.

![Even the chipmunks are at it](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081110_46421-133x200.jpg "Chipmunk namasteing")Even the chipmunks are at it



Unfortunately the serenity soon fades as noisy school groups and loutish kids come through. We both search for sanctuary, but fail to find the promised peace that we’d hoped for. Late lunch back at the 3 Foxes and we’re ready to leave Lumbini – our room begins to feel like a prison and we long for Kathmandu.

![Crowds at Lumbini](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081110_46821-200x133.jpg "Crowds at Lumbini")Crowds at Lumbini



What had looked like a straightforward solution of a bus from Lumbini dissolves into bus strikes. Our mood makes this feel like a major barrier, but the reality is that an overpriced taxi to Bhairawa connects us to a bus out East.

We contemplate the Crane Sanctuary and Japanese food, but it feels like too much of an effort and we’re fed up of being ripped off. Sweetcorn soup suffices and we sleep.