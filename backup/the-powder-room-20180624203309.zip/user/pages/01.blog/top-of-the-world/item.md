---
# http://learn.getgrav.org/content/headers
title: Top of the world
slug: top-of-the-world
# menu: Top of the world
date: 09-08-2006
published: true
publish_date: 09-08-2006
# unpublish_date: 09-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,snow,travel,new zealand,snow,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**3rd August 2006, 18:00**  
*Alpine Resort, after an exhausting day*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/meatsunrise.jpg "Me looking out over sunrise at TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/meatsunrise.jpg)Today was a bit cloudy and the sunrise was awesome but as the day rolled on, the clouds rolled in and visibility dropped. The cloud was kinda mid-level so the very top of the Saddle was nice and clear, but from about halfway down, it was pretty much zero!

Not to worry though, cos Tom decided to hike us up to the summit of Treble Cone – totally awesome! Mindblowing views as we looked down on top of the clouds!

After tip-toeing around and getting a bit giddy, we dropped off back into the Saddle, snow was a bit scratchy, but lots of nice powder patches – well worth it!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/boysatsummit.jpg "Tom, Rob, Steve and I at the summit of TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/boysatsummit.jpg)[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tomandiatsummit.jpg "Tom and I at the summit of TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tomandiatsummit.jpg)[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tomandsteveatsummit.jpg "Tom and Steve at summit of TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tomandsteveatsummit.jpg)