---
# http://learn.getgrav.org/content/headers
title: 
slug: 924
# menu: 
date: 07-06-2009
published: false
publish_date: 07-06-2009
# unpublish_date: 07-06-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

A sense of almost calm descended on me a few minutes ago. A realisation (?) that I need to leave here, that I’m driven to do something about what I see as being wrong. That is what gives me a sense of purpose and being. A way of acknowledging my interconnectedness, of helping others and feeling good as a result of it.

I came to Japan in a vague quest for peace and tranquility, of rest within my heart. Yet I’ve not been comfortable with sitting in rest. In some ways, this time has been like a retreat. A retreat from life. From world. It’s given me time on my own, with nothing to do. It’s forced me to listen to the infinite silence. I’ve resisted and occupied my days with distraction, but somewhere in that, I’m beginning to hear pots of hunny calling me.