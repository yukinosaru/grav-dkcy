---
# http://learn.getgrav.org/content/headers
title: Bluetooth baby!
slug: 
# menu: Bluetooth baby!
date: 24-01-2017
published: false
publish_date: 24-01-2017
# unpublish_date: 24-01-2017
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Learning in the Open]
    tag: [android,bluetooth,classes,inheritance,java,android,bluetooth,classes,inheritance,java]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Part of my commitment to learning in the open…

I thought I’d have a go at developing a Bluetooth baby monitor app that listens for sound and transmits it to a Bluetooth audio device when it hears something loud enough.

Has shown up gaps in my knowledge about basic Java  
 Abstract classes vs interfaces – has made me think deeper about object-orientation. Realised that I need to be a bit more methodical in developing class architecture – rather than doing it on the fly. Tend to write it fairly procedurally then retrofit.

Confusing static and final – now clear, but I keep forgetting.

Bluetooth Profiles

AudioRecord  
 Threads  
 Frustrating re levels – finding maximum values. Short is non-symmetrical.