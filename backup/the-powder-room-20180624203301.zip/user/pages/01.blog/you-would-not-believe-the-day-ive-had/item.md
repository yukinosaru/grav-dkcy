---
# http://learn.getgrav.org/content/headers
title: You would not believe the day I&#8217;ve had!
slug: you-would-not-believe-the-day-ive-had
# menu: You would not believe the day I&#8217;ve had!
date: 11-12-2006
published: true
publish_date: 11-12-2006
# unpublish_date: 11-12-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [synchronicity,travel,synchronicity,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**Sunday 10th December, 2006**  
*The McKellar household, near Boulder, Colorado!*

Wow. I’ve arrived, and in entertaining fashion! I’ve had the most amazing and fun day ever today, somehow the universe has conspired to get me here and I’m very grateful for it.

So, I rocked up at the airport nice and early, asked to get on a standby flight and was told that I needed 17 no-shows if I was to stand a chance. Determined not to despair, I smiled politely and wandered off muttering “I will get on this flight, I will get on this flight”.

At check-in, my snowboard bag was way overweight and they said I couldn’t take it on the plane. After much pleading and patience, a lovely lady called Yvonne eventually let me repack another bag and pay an excess fee. Problem was, I didn’t have another bag, so off I ran to buy a new one.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00278.jpg "My boarding pass")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00278.jpg)Anyways, I had to wait around for an hour to find out if I could get a seat. Somehow, I got the last seat on the flight and went racing off to pay my departure fee and clear security. It took forever cos you get checked 3 times and the whole way I was checking my watch. So as I cleared security (having had my lip balm confiscated!) there were only a few minutes left, so I raced to an internet machine, emailed Jen to let her know and booked myself on a flight from LA to Denver – the same one as Jen! I got to the gate and fortunately, the flight was delayed, which meant I could get on it. I have never been so happy to be on a plane!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00279.jpg "Me with boarding pass")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00279.jpg)The flight was late coming into LA, which meant that I had an hour to get my next flight – so I raced round the airport and was first in line at immigration (never had that before!), only to have to wait an hour for my bags! So I missed the flight by about a minute. Damn.

But Qantas rebooked me on the next flight for free and waived the excess baggage fee for me – they even gave me $15 to buy food with (I’ll still never fly with them again!). So, Jen had no idea I was coming and neither did Ann and Gordon (Amy’s parents – who were picking Jen up). I had no idea what I was going to do in Denver and I couldn’t get hold of Ann or Gordon. So I rang my mum and asked her to email Jen to let her know and then jumped on the flight.

Hanging around meant that I met a few snow bum types and got chatting with Andy – a kiwi originally, but is now a permanent resident in Vail of all places. We ended up on the same flight and sat next to each other, gassing all the way. I was talking about what I was going to do when I arrived and he said “No worries! My friend Allie’s picking me up, she’ll drop you in Boulder on the way” – the kindness of strangers never ceases to impress!

In the end it all worked out, cos Allie let me call and I managed to get hold of Gordon. Allie dropped me at a gas station, where Gordon was waiting with Jen!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00280.jpg "Sunset in Auckland")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/dsc00280.jpg)So there we are – am now safely here, with all my bags and my hair intact, in a lovely house in Colorado! The sun has set on our time in New Zealand, but winter has only just begun in the States!