---
# http://learn.getgrav.org/content/headers
title: Closing Time
slug: closing-time
# menu: Closing Time
date: 19-03-2009
published: true
publish_date: 19-03-2009
# unpublish_date: 19-03-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [reflection,snow,reflection,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

It’s the end of the season here. The melt is kicking in, I’ve finished work, goodbyes are being said, grass is reappearing, things are changing. It’s a schizophrenic time of year; sad because the unique set of people and circumstances that made up this season will never be again, yet exciting, flowers start to bloom, people are off to new places, new adventures, new friends. It’s OK to be sad about times gone past, but in the words of Semisonic ‘Every new beginning comes from some other beginning’s end’.

Synchronicity or not, but I was chatting with a friend earlier today and she reminded me of another Robert Frost poem I love:

[![Reflection](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/img_61401-200x141.jpg "Reflection")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/img_61401.jpg)Nature’s first green is gold,  
 Her hardest hue to hold.  
 Her early leaf’s a flower;  
 But only so an hour.  
 Then leaf subsides to leaf.  
 So Eden sank to grief,  
 So dawn goes down to day.  
 Nothing gold can stay.