---
# http://learn.getgrav.org/content/headers
title: I passed!
slug: i-passed-2
# menu: I passed!
date: 16-02-2009
published: true
publish_date: 16-02-2009
# unpublish_date: 16-02-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [exam,instructing,japan,exam,instructing,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Hurrah, I am now an official, bona-fide ski instructor! Woohoo. So I only just scraped through on my riding, but a pass is a pass. Out tonight celebrating with everyone (who all passed!).  
 We had just about every type of weather over the last few days, chucking it down with rain, blowing a gale and then heavy snow and wind on the last day. Poor Gavin and Brian had to stand around outside in freezing and horrible conditions.  
 My skiing was pretty sketchy for most of the week, but something came together at the end and I started to feel that I was skiing like I was in Winter Park, which was a relief.  
 Anyway, job done – one step closer to ISIA certification!