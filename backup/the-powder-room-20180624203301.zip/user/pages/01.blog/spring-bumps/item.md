---
# http://learn.getgrav.org/content/headers
title: Spring bumps
slug: spring-bumps
# menu: Spring bumps
date: 30-08-2006
published: true
publish_date: 30-08-2006
# unpublish_date: 30-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**30th August 2006, 2146**  
*On the sofa (again!)*

Was roasting today – glorious and sunny, but way too warm. Spring is creeping up on us! Spent the morning on the platter practising the BASI Central Theme – basically the beginner stuff. Being a geek, I found it real interesting to compare it to the NZSIA approach.

For the afternoon, we all rode together and hit the bumps in powder bowl – tough work, but great fun – Neil even said that my run would be a pass in the exam. Also managed to make my first grab on a straight air today – and it’s even on video! It must have been the demo board, cos I managed to land a 180 later on. Really enjoyed the board today, but will try a few others – have picked up a Burton Seven to try tomorrow.