---
# http://learn.getgrav.org/content/headers
title: Busy, busy, busy
slug: busy-busy-busy
# menu: Busy, busy, busy
date: 16-06-2006
published: true
publish_date: 16-06-2006
# unpublish_date: 16-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Phew! Busy few days, finished work last friday, had some leaving drinks on Saturday, then have been frantically trying to pack and clear all my junk away.  
 Really beginning to get excited now, but it’s just dawning on me how difficult it is going to be to leave Jen – but must stay positive and just remember that it means that we’ll be living (and travelling!) together in 3 months time!

My plan’s have changed slightly now, flying into Christchurch and picking up a car there (somehow?!). Then taking a couple of days to drive down to Wanaka, before hitting the slopes in Cardrona for a few days.