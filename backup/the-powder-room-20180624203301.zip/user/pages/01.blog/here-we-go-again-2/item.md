---
# http://learn.getgrav.org/content/headers
title: Here we go again&#8230;
slug: here-we-go-again-2
# menu: Here we go again&#8230;
date: 12-02-2009
published: true
publish_date: 12-02-2009
# unpublish_date: 12-02-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [exam,instructing,japan,exam,instructing,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

So I started my NZSIA Level 1 Alpine Ski exam tonight with an indoor session. Everyone seems pretty cool and Gavin, our examiner, is a really nice guy. I’m feeling quite relaxed about this exam although I know my skiing is a little borderline. I’ve been working on it as much as I can, but work has been getting in the way a bit!  
 It feels a little odd to be doing another exam and very different from my previous ones. Partly because I’ve done it before and partly because it’s not had such an intense build up of training and analysis. I feel a little under-prepared compared to how I felt before my CSI exam, but confident in my teaching and technical knowledge (I should hope so given that I taught skiing for a season!).  
 The exam is over 4 days:  
 Day 1 – Progression from first timer to advanced wedge turns  
 Day 2 – Applying the progression to kids  
 Day 3 – Wedge demo assessment and freeriding assessment  
 Day 4 – Teaching assessment

You can’t really fail in the first 2 days, which is a relief. They basically are a course, which gives us time to work on our freeskiing and technical knowledge.