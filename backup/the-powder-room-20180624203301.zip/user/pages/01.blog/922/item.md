---
# http://learn.getgrav.org/content/headers
title: 
slug: 922
# menu: 
date: 04-06-2009
published: false
publish_date: 04-06-2009
# unpublish_date: 04-06-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

So I’m probably going home in a few weeks. And I don’t know why or what I’m trying to do. Am I just looking for the comfort of familiarity? Is it an ego and status thing? Is it just the novelty of change? Is it the fear that I’ve fucked around too much and have a patchy CV? That I need to ‘get on with my life’? I came here to chase a rainbow – am I giving up on it? Or is this a development? Is this part of a path to a possible future in the mountains? Or becoming a consultant? Or a DFID advisor?

I can see how this might pan out. Worry that it will or that it won’t or that I’ll affect the future somehow.

I believe that climate change has the power to change the world for the better. This could be a way of being involved in that. Doubts: Do I really? Or is that a convenient grand vision?

Am I just trying to explain myself to others?