---
# http://learn.getgrav.org/content/headers
title: Tourist Bus
slug: tourist-bus
# menu: Tourist Bus
date: 03-11-2008
published: true
publish_date: 03-11-2008
# unpublish_date: 03-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Nepali quality bus](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081103_4323-200x300.jpg "Quality Nepali bus")Nepali quality bus



First of many early starts! Off to Pokhara and realised what that great cheap deal bought us, passing neat and clean buses to arrive, mildly despondent at a rickety green bus. Our bags unceremoniously hauled on top, street hawkers all round selling water, crisps and pastries. Were we going to get to Pokhara? As the bus set off, the unmistakable sound of metal on metal screeched up from below. Fortunately, after driving for a bit in Kathmandu traffic(!), we stopped to fix the brakes.

![Terraced fields](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081103_4347-300x200.jpg "Terraced fields")Terraced fields



![Annapurna from the bus](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081103_4336-300x200.jpg "Annapurna from bus")Annapurna from the bus



A surprisingly pleasant journey up and out of the Kathmandu smog to look over the valley with its tall brick factory chimneys, changing to steep-sided terracing and winding mountain roads. A snooze. Our first glimpse of mountains. More sleep. Short dal bhat stopÂ  by the river. Soon death defying overtaking manoeuvres, protected only by the magical power of the horn, rapidly eliminated the possibility of sleep.

![Bear-shaped cloud over Pokhara](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081103_4351-200x300.jpg "Bear shaped cloud")Bear-shaped cloud over Pokhara



Exhausted but excited arrival in Pokhara Mustang bus station. Offloading into a melee of taxi drivers. NO I AM NOT JAPANESE. Hoisting overladen bags onto shoulders in blazing sun, we pushed through and started walking in defiance, ignoring claims of a 3 mile walk. 10 minutes later and sweating buckets, we checked into the Gauri Shankar, as much through heat exhaustion as recommendation.

Slightly eccentric Judy, our Australian host sees through my attempted name-dropping discount scam and Ram shows us our room. Showers (aah!) and preparation for trekking precede delicious Japanese food at Koto and a much needed sleep.