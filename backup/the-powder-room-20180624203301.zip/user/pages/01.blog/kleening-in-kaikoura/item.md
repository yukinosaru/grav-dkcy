---
# http://learn.getgrav.org/content/headers
title: Kleening in Kaikoura
slug: kleening-in-kaikoura
# menu: Kleening in Kaikoura
date: 25-10-2006
published: true
publish_date: 25-10-2006
# unpublish_date: 25-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**25th October 2006**  
*Dusky Lodge, Kaikoura*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1890.jpg "100% NZ")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1890.jpg)Today is our last day in Kaikoura and the sun has come out. This may not seem a big thing for you folk, but the rain has been the bane of our travels so far! We arrived in a gloriously sunny Kaikoura and filled with excitement (but a singular lack of funds for that week), we eagerly signed up to a week of cleaning in exchange for accommodation at what we thought was the luxurious Dusky Lodge.

Oh how wrong we were.

{mosimage} So, pleased with ourselves and having soaked in the hot tub, we awoke the next day to head off whale watching – possibly the only saving grace of our experience in Kaikoura. Saw 2 sperm whales, dolphins and stuff, but that’s not the point of this entry.

We returned to the delights of bed making and bog cleaning, using little more than old rags and what can only be described as milky water (or multipurpose cleaner as they seemed to call it…).

Anyway, it rained for 5 days. When I say it rained, imagine someone pouring bucket after bucket of water over you. And then switching on the hosepipe and a wind machine.

We made the most of it though and joked with our cleaning compadres about how we kept on bringing the bad weather with us and when we left it would clear up, ho ho bloody ho.

So, I hope you can understand our somewhat mixed emotions at the sight of blue sky and oh, were those mountains always there?

PS We went to Hanmer Springs and Christchurch too.