---
# http://learn.getgrav.org/content/headers
title: 26 today, 26 today!
slug: 26-today-26-today
# menu: 26 today, 26 today!
date: 01-08-2006
published: true
publish_date: 01-08-2006
# unpublish_date: 01-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,snow,new zealand,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**1st August 2006, 18:00**  
*Alpine Resort, after a stoked day!*

Hurrah! What a birthday, woke up this morning with some presents sent from Jen and great snow. After our warm up, Tom took us (Steve, Rob, Mark and I) over to the Saddle Basin. Just as we got to the top, the Motatapu Chute opened up, so we raced over and got first lines down! Absolutely amazing! The downside was the 30 minute hike out of there, but well worth it!

We’ve got a meeting tonight about jobs in the States and then we’re going for dinner at the White House (thanks for the recommendation Jane!), before a few cheeky bevvies at Woody’s. Can’t wait!

Decided to treat myself too, so just about to head out to buy myself a new jacket – got to look the part! Plus we’re going heliboarding tomorrow – top that for a birthday!