---
# http://learn.getgrav.org/content/headers
title: Doris!
slug: doris
# menu: Doris!
date: 22-06-2006
published: true
publish_date: 22-06-2006
# unpublish_date: 22-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [doris,doris]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**22nd June 2006, 20:00**  
*City Centre YHA, Christchurch*

Just bought myself a Toyota Hi-ace campervan called Doris! Complete with windchimes and gas stove – provided she passes a pre-purchase inspection, I’ll be winging my way to Wanaka on Sat. Texted Jen to let her know – we’ve got our first home!! (ok, it’s in another country, but it’s still ours!)

. Snow has been falling thick and fast, even in Christchurch – was supposed to be boarding in Mt Hutt, but it was shut cos there was too much snow – 40cm fell in 2 hours! We’ve rescheduled for tomorrow, so hopefully it clears and we’ll have lush powder to play with!