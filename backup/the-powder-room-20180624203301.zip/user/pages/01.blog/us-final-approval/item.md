---
# http://learn.getgrav.org/content/headers
title: US Final Approval!
slug: us-final-approval
# menu: US Final Approval!
date: 30-11-2006
published: true
publish_date: 30-11-2006
# unpublish_date: 30-11-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [travel,visa,travel,visa]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**30th November 2006**  
*Mousetrap*

Finally, the news we’ve been waiting for – the I797 final approvals have come through for snowboard instructors and I can book an interview in Auckland! Hurrah! We’re just waiting on Jen’s one now, but fingers crossed they’ll be through soon. Such a relief!