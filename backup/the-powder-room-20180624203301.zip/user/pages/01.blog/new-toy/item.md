---
# http://learn.getgrav.org/content/headers
title: New toy!
slug: new-toy
# menu: New toy!
date: 06-09-2006
published: true
publish_date: 06-09-2006
# unpublish_date: 06-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**6th September 2006, 21.59**  
*On me sofa, having cleaned the kitchen*

Awesome (must stop using that adjective…) day today – snow is still a bit rubbish today, but it was a bit colder today and there was a little fresh last night, so all in all, it wasn’t too bad! We had yesterday off-mountain because of the rain, but it was a good break.

I’m in a group with Tom as our trainer this week – still with Pete, Claire, Nipper and Chelsea. We’ve been working on improving our flow and moving fore and aft on the board a bit more. Had a bit of a breakthrough on Monday with Tom and practised it a bit today – starting to feel more fluid in my riding now. Still need to work on my heelside posture (I tend to break at the waist), but we did a great exercise with Neil last week that really helped – he dragged us around with a drag lift handle to get us to resist and stand up properly.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/newboard.jpg "My new Capita Shapeshifter")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/newboard.jpg)[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/newboard2.jpg "My new Capita Shapeshifter")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/newboard2.jpg)But the real exciting thing today was a new board! Having demoed the Burton Seven and not liking it, I tried a Capita Shapeshifter – and loved it! So, I’ve treated myself to one, managed to get quite a bit off cos it’s the end of the season and cos I’m a qualified instructor!.

Can’t wait to play with it tomorrow – looking forward to BASI exam now, feel less stressed about it, partly because of the style of the trainers and partly because I know I’ve got my NZSIA already.