---
# http://learn.getgrav.org/content/headers
title: Back to Kathmandu
slug: back-to-kathmandu
# menu: Back to Kathmandu
date: 11-11-2008
published: true
publish_date: 11-11-2008
# unpublish_date: 11-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Goat on the roof of a passing bus](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081111_46881-133x200.jpg "Goat on the roof")Goat on the roof of a passing bus



We probably didn’t do Lumbini justice, but we’re pleased to leave. The early morning mist and sunrise warm our hearts. We arrive early in Bhairawa and dodge bus drivers to contemplate our mode of transport. After waiting for it to arrive, we pay 750 rupees each for an A/C bus. Glorious luxury! Comfy seats, air conditioning, clean water, fantastic break stops. Overpriced, but worth it. Our bags were even in the boot!

We’re dropped rather unceremoniously on the outskirts of Kathmandu and after wandering around in the dust, pollution and noise, we find a tempo to Ratna Park for a mere 15 rupees. We find the Horizon Hotel and breathe a sigh of relief. O fukura no aji for dinner as we can’t see to find Koto.