---
# http://learn.getgrav.org/content/headers
title: Lucky man
slug: lucky-man
# menu: Lucky man
date: 20-03-2011
published: true
publish_date: 20-03-2011
# unpublish_date: 20-03-2011
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Rocked up in san francisco a few days ago to see my mate Gav – left to my own devices for a few days, I rashly [booked a camper](http://www.lostcampersusa.com/ "Lost Campers") and headed to Tahoe. Decided on [Squaw Valley](http://www.squaw.com/ "Squaw Valley"), checked out the forecast – 2 feet of fresh and more on the way! Totally by chance I seem to have picked possibly the place with the best snow conditions on the planet.

![](http://user47216.vs.easily.co.uk/wp-content/uploads/2011/03/IMG_20110320_102249-200x150.jpg "In the trees")I love trees



Cruising out of the city on the Interstate 80, rain lashing down, which means snow in the mountains! Epic drive, with 100 mph winds and driving snow over the donner pass. A 3 hour trip end up taking more like 5, plus breaks to calm my rattled nerves and fire up my caffeine levels. Eventually roll into Squaw at 1am, crawl into the back of the van and fall asleep.

 

Next morning I’m woken by the sounds of ski patrol blasting avalanches with dynamite at around 6. Excitedly chucking on my snow gear, I throw back the door.

Well, I try to.

In just a few hours the snow has reached door level on the van and I’m stuck! My genius, free spirited car danchi adventure hadn’t factored in the reality of several feet of snow in a few hours. Fortunately the sliding door opens and I shovel my way out. After a bit of cursing and digging, I eventually free the car and drive round the corner to the lifts… which are pretty much all shut. 82 inches of snow in two days with strong winds has totally overwhelmed the staff and hiked up the avalanche risk astronomically. Turns out the I80 has been shut and I has missed the Caltrans advice not to travel. Oops. So now I’m stuck in Squaw no way in or out until the winds stop. Ordinarily this might be cause for concern, but I have time on my side.

![](http://user47216.vs.easily.co.uk/wp-content/uploads/2011/03/IMG_20110320_102303-200x150.jpg "Anyone seen my knees?") Fortunately some of the lower lifts open a few hours later and I eagerly scramble onto one, unload, strap in and hungrily eat up the thigh deep powder. Now riding powder is one of those things where if you have to ask why it’s so great, you wouldn’t understand! Slashing through a turn, a perfect arc of snow cascading behind you like magic sparkles; punching through pillows, your snow covered face cackling insanely; looking down, trying to remember what your knees look like. Trust me, it’s good!

Such brings me to now, beer in hand, exhausted, happy, a little lonely without my friends and M, but full of the beauty of life, perfectly encapsulated by tiny little unique crystals of water falling freely from the heavens.