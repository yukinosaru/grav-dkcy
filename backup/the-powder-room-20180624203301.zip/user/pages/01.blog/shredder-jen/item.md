---
# http://learn.getgrav.org/content/headers
title: Shredder Jen
slug: shredder-jen
# menu: Shredder Jen
date: 04-03-2007
published: true
publish_date: 04-03-2007
# unpublish_date: 04-03-2007
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [snow,winter park,snow,winter park]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**3rd March 2007, 21.27**  
*Sitting on the sofa in the lounge*

So we’ve been doing a fair bit of filming on the slopes and I thought I’d put together a little clip of Jen’s riding around! She’s been doing fantastically, but I’ll say no more, see for yourself  
[Jen riding](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/jenriding.mov)

PS Note that there’s no footage of me – everytime we try to film me, oh, the batteries have run out. Bloody typical.