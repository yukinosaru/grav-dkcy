---
# http://learn.getgrav.org/content/headers
title: More ramblings&#8230;
slug: more-ramblings
# menu: More ramblings&#8230;
date: 17-05-2006
published: true
publish_date: 17-05-2006
# unpublish_date: 17-05-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**17th May 2006, 21.30******  
***At home with the Champions' League final in the background (Barca have just scored again, Arsenal not happy)*

Slightly irritated as I clicked the wrong button and appeared to lose my entry!! Grr.

Anyways, was rambling again, 15 days of work left. Have just moved out of my flat and  back to my parents for the next few weeks. Had a moment of total fear yesterday, but talked about it with Jen and am sure this is the right thing to do and was always going to be difficult to leave this all behind!  
 What else has been happening? Well, still doing Capoeira, but probably  
 less now that I'm in Sutton. Decided to do a 10k run in Battersea Park  
 – whole world of pain, but pretty chuffed with myself – no training and  
 finished in under an hour. Can see how people get into running, was a  
 real mental challenge to keep myself going and had a moment of total  
 euphoria and a surge of energy after about 7k – was quite uplifting.

Got myself some new kit too – finally ditched the Flows for something a  
 bit more suitable – Burton Cartels, last season's kit, but a bit  
 cheaper and still lush! Been rocking back and forth on them in my room  
 – quite sad really! Need some real snow!

Meeting some other Rookies for drinks in London, should be good craic –  
 even if some are skiiers! ;p There's going to be quite a few of us out  
 there, was looking at some photos that people have posted from last  
 year – just looks awesome. Can't quite believe it's happening yet and  
 that I'll be living in Wanaka for 13 weeks! Totally stoked!