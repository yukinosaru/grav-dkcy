---
# http://learn.getgrav.org/content/headers
title: Queenstown
slug: queenstown
# menu: Queenstown
date: 11-10-2006
published: true
publish_date: 11-10-2006
# unpublish_date: 11-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**7th October 2006**  
*Queenstown*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/bensenblock.jpg "Bottles in Doris")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/bensenblock.jpg)So we left Wanaka on Saturday and headed for Queenstown over the Crown Range road – the highest sealed road in New Zealand. Bit of struggle with Doris and quite hairy on the way down, but fine!

Queenstown was beautiful, but quite built up and hectic after the serenity of Wanaka. It felt heavily commercialised and every second store was an extreme sports booking office. All in all, it was a little disappointing, but we headed on through and down the road to Glenorchy. About 15 minutes out of Queenstown, we pulled over at a neat little Department of Conservation (DOC) campsite, where we got to camp right by Lake Wakatipu, looking out at the Remarkables. The perfect spot for our first proper night in Doris.