---
# http://learn.getgrav.org/content/headers
title: Black and white
slug: black-and-white
# menu: Black and white
date: 28-08-2006
published: true
publish_date: 28-08-2006
# unpublish_date: 28-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**28th August 2006, 14.09**  
*In my living room, drinking lapsang souchong and listening to cheesy music*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/stage-1-certificate.jpg "Stage 1 Certificate")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/stage-1-certificate.jpg)So there we have, I’ve passed. Wow. Can’t quite believe it, but it’s there on paper, in black and white. It takes the pressure off slightly, cos at least I’ve got the NZ qualification. We’ve got today off, then 2 more weeks of training, then 2 weeks of the BASI Instructor exam, but I’ll worry about that tomorrow.

Not sure how I feel, but it’s a bit of an anti-climax and I’m a little bewildered. The overwhelming sensation is that of complete mental, emotional and physical exhaustion.

My main feedback was on my riding. Basically, I need to soften up a bit and develop more progressive vertical movement, particularly in my edged turns. I really don’t think I deserved to pass – and I actually said that to Greg in our feedback session. He thinks that I’m smart enough to know what I need to do and that I just need more mileage. I’m grateful for his faith and thankful that I’ve passed, but I feel like a fraud and know that I’m not an instructor-level rider. But then again, I guess you don’t need to be the best rider to be a good instructor. I feel my mind is a little clouded and everything is grey around the edges, and for once, that’s nothing to do with a hangover!