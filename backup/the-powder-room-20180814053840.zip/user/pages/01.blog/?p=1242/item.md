---
# http://learn.getgrav.org/content/headers
title: 
slug: 
# menu: 
date: 05-02-2014
published: false
publish_date: 05-02-2014
# unpublish_date: 05-02-2014
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Dessalegn eclipsed by admasu.  
 Mofed taking control. Impatient with waiting.  
 Mef remains weak and not powerful.  
 Process crept forward but no real progress until mofed stepped in.