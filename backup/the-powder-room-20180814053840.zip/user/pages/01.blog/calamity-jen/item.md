---
# http://learn.getgrav.org/content/headers
title: Calamity Jen
slug: calamity-jen
# menu: Calamity Jen
date: 09-12-2006
published: true
publish_date: 09-12-2006
# unpublish_date: 09-12-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**7th December 2006**  
*Devonport, Auckland*

\*sigh\* calamity Jen strikes again. Not content with how smoothly things were going, Jen decided to hurt herself snowboarding today. She managed to twist her ankle quite badly (despite my initial protestation that it was all ok) and is now hobbling around. I don’t think it’s anything major, but enough to give her a limp for a while. Hopefully she’ll be right as rain soon enough!