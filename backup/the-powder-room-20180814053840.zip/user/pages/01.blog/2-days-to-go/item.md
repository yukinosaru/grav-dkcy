---
# http://learn.getgrav.org/content/headers
title: 2 days to go&#8230;
slug: 2-days-to-go
# menu: 2 days to go&#8230;
date: 20-09-2006
published: true
publish_date: 20-09-2006
# unpublish_date: 20-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**20th September 2006, 19.38**  
*Alpine Resort*

Teaching went well today and we had the written exam today too – think that was pretty sweet, so all that’s left to do is the riding assessment. We’ve been continually assessed and last week’s riding was pretty poor by me.

But I’ve had lots of feedback and worked hard on things, so hopefully I can prove myself tomorrow. Just need to focus and remember to relax too!

Chew taught us how to ride boxes too today and I nailed a straight box about 4 or 5 times. Even tried a nose slide (where the tail of the board hangs off the box as you slide along) – just about managed that too – really enjoyed that and look forward to playing a bit more after the exam is over!

On other news, Jen got the job at Winter Park! So we’re all set to head over there, just need to figure out the visa situation – but from initial investigation, doesn’t seem too bad! Can’t believe it is actually happening – will be awesome to be in Colorado!