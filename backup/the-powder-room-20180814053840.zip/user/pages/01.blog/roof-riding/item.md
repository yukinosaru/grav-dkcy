---
# http://learn.getgrav.org/content/headers
title: Roof-riding
slug: roof-riding
# menu: Roof-riding
date: 04-11-2008
published: true
publish_date: 04-11-2008
# unpublish_date: 04-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Luxury seats](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081104_4366-200x300.jpg "Roof riding")Luxury seats



Early start and taxi to Baglung bus station. We are dropped off and not a sign of a westerner around. No idea which bus to get – not that there are any. Running the gauntlet of taxi-drivers again, we manage to find where to wait. Bus arrives, driver shouts 75 rupees and says ‘on top’ – unclear whether he means us or the bags, I clamber up and shove my bag into a niche. Concern, moments of fear – go with it and end up sitting on the roof, gripping for dear life. We are joined by David and Sir (his porter) – caught in a travelling moment we bond.

![Making friends](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081104_4372-300x200.jpg "Roof riding - other bus")Making friends



Relaxing a little, I tense up again as Dave is side-swiped by a branch and I’m suddenly very aware of the garroting potential of electricity cables. Still, I soon sink into it, gripping bars with grubby feet. It’s windy and the temperature begins to drop. A few flecks of rain cause momentary panic, but the downpour never materialises.

We arrive at Naya Pul – a collection of shacks. A rather scrappy dismount and hasty booting up, then we are left in the relative quiet. We follow Dave and Sir to find the path to Birethanti, a pleasant and well equipped village that represents the real start of the trek.

![View from Indra Guesthouse](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081105_4385-200x300.jpg "View from Indra guesthouse")View from Indra Guesthouse



A long day of steep trekking and some confused map-reading. We begin to doubt how sensible it is to carry our own things. Our destination seems to further and further away, but eventually Tikhedunga emerges and a glance at my watch reveals that we’re spot on time. We spot Dave at the Indra guesthouse and opt to stay there.

Hot showers, cup of tea and we meet Noel and Jess. More dal bhat, sleep and nerves about the next day.