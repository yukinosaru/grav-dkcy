---
# http://learn.getgrav.org/content/headers
title: Last night in South Island
slug: last-night-in-south-island
# menu: Last night in South Island
date: 31-10-2006
published: true
publish_date: 31-10-2006
# unpublish_date: 31-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**31st October, 10.18pm**  
*Sequoia Lodge, Picton*

I’ve been really slack at blogging, but I’ll get round to filling in the blanks later! Anyways, we’ve been buzzing all over the South Island in the past few weeks – ice climbing on Franz Josef Glacier, driving through Arthur’s Pass, stopping in Christchurch, whale watching, rain watching and cleaning (!?) in Kaikoura and sea kayaking in Abel Tasman. Phew! Told you there was lot to fill in! (*PS It’s all filled in now! Check out the new entries*)

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1943.jpg "Jen")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1943.jpg)We’ve spent the last four nights in Abel Tasman (one of which was in a rather wet campsite in Anchorage), sea kayaking with Southern Exposure. Yet again, the first day was gloriously sunny and then it started to rain (again). So our 2 day trip was cut short as we were rescued by water taxi like drowned rats and taken home by a nice man called Al. Got some great video of Jen looking as green as the water as we were thrown about in 3-4m waves.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_1956.jpg "Abel Tasman")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_1956.jpg)But the hostel we stayed at was lovely so we stayed on and persuaded Kathy (co-owner) to let us go on a 1 day trip for a mere $50. Fortunately the sun came out for us and we had a top day paddling with seals.

We’re in Picton now, which is where we get the ferry to North Island from. We’re in a lovely hostel with a free bubbly spa and lots of hammocks!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1948.jpg "Abel Tasman")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683651_img_1948.jpg)So, this is the end of the South Island for us, we’re off to Wellington tomorrow and then northwards until the 18th November.