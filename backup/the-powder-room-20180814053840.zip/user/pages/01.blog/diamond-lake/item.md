---
# http://learn.getgrav.org/content/headers
title: Diamond Lake
slug: diamond-lake
# menu: Diamond Lake
date: 26-07-2006
published: true
publish_date: 26-07-2006
# unpublish_date: 26-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**26th July 2006, 17.30**  
*Alpine Resort*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/diamondlake.jpg "Diamond Lake")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/diamondlake.jpg)Much needed day off today – sorted a few bits and bobs then had lunch and went for a nice walk with Claire, Pete and Ryan.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/peteandi.jpg "Pete and I on Diamond Lake")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/peteandi.jpg)We were supposed to go for a gentle stroll round Glendhu Bay, but ended up hiking up to Diamond Lake – not that far, but more than I was dressed for! Well worth it though, as we were treated to a frozen over lake in the shape of a heart.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/ryanandclaire.jpg "Ryan and Claire walking off into the sunset")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/ryanandclaire.jpg)After tentatively stepping onto the ice and chucking a few rocks, we decided it was actually strong enough to walk on.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/afternoonsun.jpg "Afternoon sun in Wanaka")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/afternoonsun.jpg)Anyways, was a lovely day and topped off with some glorious afternoon sun as we strolled back!.