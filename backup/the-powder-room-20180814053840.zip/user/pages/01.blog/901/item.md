---
# http://learn.getgrav.org/content/headers
title: 
slug: 901
# menu: 
date: 25-05-2009
published: false
publish_date: 25-05-2009
# unpublish_date: 25-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Feelings of lost – being stuck. Slightly panicky. Hiding from the world, don’t want to see anyone, but don’t want to do nothing. Procrastinating about work. Feel like I’ve already left here in my head. Sadness, confusion. No money, running low on food. Need to make decisions, but feel paralysed into inaction. Wheelspinning in the mud. Lost control of my world, events happen to me.