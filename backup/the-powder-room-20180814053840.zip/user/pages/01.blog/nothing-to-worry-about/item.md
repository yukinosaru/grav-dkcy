---
# http://learn.getgrav.org/content/headers
title: Nothing to worry about
slug: nothing-to-worry-about
# menu: Nothing to worry about
date: 17-07-2006
published: true
publish_date: 17-07-2006
# unpublish_date: 17-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**17th July 2006, 21.01**  
*Alpine Resort – watching some tat film on rubbish NZ TV*

Day one of the CSI exam and it went really well – Jim’s clearly been putting the wind up us to make sure we do well!

I’m in a group with Claire and Guy from Rookies and some other folk from the training school in Cardrona – we’ve got Paul and Jeremy Coombs as our examiners – Jeremy just happens to be the course director for Snowboard Instructors NZ (SBINZ – who are responsible for all the instructor training in NZ)!

But it was all cool – just working through the movements, board performance concepts, the teaching progression and teaching cycle. It’s great cos we’ve done all of this in training and can give the answers in a pretty confident way. Trying to think of this as a week long interview, so trying to be as professional as possible and get into the mindset that I’m an instructor.

Went to the physio again today and she’s pleased that things are getting better – just need to keep gently stretching it and then a final check up on Thursday – she reckons I should be back to 100% by the end of the week – result!

Jen’s handed her notice in today at work – very exciting and means we’re one step closer to being together again! Been chatting with Dean (Hunter, who runs the Rookie Academy) about employment and looking for proper jobs for Jen – he was pretty positive that they’d be able to help, so I’m going to have a chat with him at the weekend to see what we can do. Would be good to take advantage of the help Rookies offer us with sorting out visas and getting placed (it can be quite difficult to get H2B visas), but it has to be right for both of us – we’ll just see how things pan out and take life as it comes! Haven’t committed to anything, but good to explore the options!