---
# http://learn.getgrav.org/content/headers
title: Wonk tools
slug: 
# menu: Wonk tools
date: 30-07-2017
published: false
publish_date: 30-07-2017
# unpublish_date: 30-07-2017
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Google docs

Collaborative and live editing

Add-ons – approvals, maps

Sheets

Scripting

Add ons – Wolfram, solver

Barriers

Cultural inertia – clients and partners who just aren’t used to it.

Why can’t consultancy be as cutting edge and dynamic as tech? Enabled and embracing of modern tools

Should be the forward thinkers, the bleeding edge. If you want to be part of this then get in touch.

Consultants’ manifesto?