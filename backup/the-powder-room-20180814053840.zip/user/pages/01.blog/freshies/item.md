---
# http://learn.getgrav.org/content/headers
title: Freshies!
slug: freshies
# menu: Freshies!
date: 05-07-2006
published: true
publish_date: 05-07-2006
# unpublish_date: 05-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**5th July, 10.58am**  
*Bits and Bytes, freezing my butt off!!*

15cm of fresh snow in the Saddle Basin yesterday – perfect conditions for our first day of on-snow training! Had a great day with Jim and picked up lots of great tips. Feel much better with my riding already!

Bit of a nervy start to the day as I had a new set up and we had to cut some turns down the beginner slope to get grouped – I was awful, but got put in with some good people – Rob, Kiwi Pete and Nick.

We were lucky too, cos we got Jim as our trainer – focussed on 4 main things today; front knee steering, turning our shoulders more, completing turns by looking across the mountain and cowboy knees to improve stance.

So I tried this on the groomers, then we did an off piste run in the Saddle and I made it down turning all the way – by contrast, two days ago, I was falling all the way down that and really frustrated!

Really enjoyed it and can’t wait to do more, there’s so much to learn and it’ll really boost our riding! Did a bit of switch, which went much better than expected.

Some icy patches, which is a bit scary and I took a bit of tumble that’s left a graze on my chin – nothing major but I look stupid now!!

Started yoga yesterday too – was pretty good although the instructor is very strict and very Germanic! Had a quiet night last night and decided to take today off to rest and sort a few bits and bobs out!