---
# http://learn.getgrav.org/content/headers
title: The Daily English Show
slug: the-daily-english-show
# menu: The Daily English Show
date: 08-03-2009
published: true
publish_date: 08-03-2009
# unpublish_date: 08-03-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,jibbing,snow,japan,jibbing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

So today was an interesting day. My back was still causing me trouble, so I called in sick at work and came home early. My friend Sarah runs a brilliant english language podcast called [The Daily English Show](http://www.thedailyenglishshow.com/) and she asked if I’d do an interview for it. I rocked up to Samurai bar in Hirafu and gave my little interview, which will be on the site shortly.

After my addition to my fifteen minutes of fame, I came back to Unitas and found a few of the boys setting up a little jib outside one of the houses, so I spent the afternoon shooting and am pretty pleased with the results!

 
			#gallery-3 {
				margin: auto;
			}
			#gallery-3 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-3 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-3 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		 [![](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)   