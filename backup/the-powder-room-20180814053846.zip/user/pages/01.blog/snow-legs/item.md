---
# http://learn.getgrav.org/content/headers
title: Snow legs
slug: snow-legs
# menu: Snow legs
date: 25-06-2006
published: true
publish_date: 25-06-2006
# unpublish_date: 25-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**26th June 2006, 10.51**  
*Bits and Bytes, but in my head Cardrona access road, nr Wanaka*

Day one of the season, Claire and I headed to Cardrona (Cardy’s as it’s affectionately referred to) to get our snow legs back. First few runs were a bit ropey and a little nervous about whether I’m good enough, but totally stoked for the season – can’t wait!!

My first couple of runs were rubbish. But after a quick adjustment to take off the forward lean, I was flying again! Starting to carve again, but not particularly well.

The snow was good, nice and dry and no ice! A little cut up as it’s been a few days since the last snowfall, but good enough for a first day.

So a day off today, sorting out a few bits and bobs, then heading to Treble Cone (TC) on Tuesday for our first ride on the mountain that will be ours by October.