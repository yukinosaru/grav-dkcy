---
# http://learn.getgrav.org/content/headers
title: Poon Hill and Pain
slug: poon-hill-and-pain
# menu: Poon Hill and Pain
date: 06-11-2008
published: true
publish_date: 06-11-2008
# unpublish_date: 06-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Very early and reluctant (for M!) start – short sharp climb up Poon Hill to watch the sun rise over the Annapurna range. Pleasant and uninterrupted views but can’t help but think we could have stayed in bed and avoided the crowds.

 
			#gallery-1 {
				margin: auto;
			}
			#gallery-1 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-1 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-1 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		 [![](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)   


We say our farewells and troop off to Tatopani. Bimbling through enjoying the downhill and relative solace, the day rolls by. After stopping for lunch, we realise how far it really is – the indicated 6-7 hours turn out to be over 8 hours! I push the pace – long steep descent, we meet a Nepali man coming the other way – he works in Tatopani during the day and at a hostel in the pass at night. He seems happy to talk and kindly gives us some clementines – delicious! Tatopani seems to be further and further – the fabled hot springs sink out of our future. Arriving at well past 5pm, we make a false start, then stay in a mangy place with cold showers and a leaky toilet. But we do make the hot springs, which just about make up for the tortuous day! Twilight bathing eases sore muscles. Mediocre food and mangy, drooling dog provide our evening entertainment.