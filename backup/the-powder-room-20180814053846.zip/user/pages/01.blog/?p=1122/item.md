---
# http://learn.getgrav.org/content/headers
title: Breakfast
slug: 
# menu: Breakfast
date: 21-02-2011
published: false
publish_date: 21-02-2011
# unpublish_date: 21-02-2011
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [For Tea Too]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

I woke up this morning with thoughts zinging round my head and somewhat impulsively fired off a couple of tweets. I can’t seem to get them out of my head, so I guess that warrants a blog post.

Nation states are incapable of managing global risk, yet there is an absence of global governance. Or perhaps more accurately,