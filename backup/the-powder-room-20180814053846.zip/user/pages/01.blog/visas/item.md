---
# http://learn.getgrav.org/content/headers
title: Visas!
slug: visas
# menu: Visas!
date: 06-12-2006
published: true
publish_date: 06-12-2006
# unpublish_date: 06-12-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [travel,visa,travel,visa]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**6th December 2006**  
*34 Cassino Street, Bayswater, Auckland*

Hurrah! It’s been a hectic few days, but we’ve now got out passports in hand with visas (and dodgy photos). So, we’ve been staying with Jo and Kevin (Twiggins – newly married, ah!) who are friends of Mez’s and we’ve been visiting Jo’s parents, Andre and Catherine who’ve let us use their internet and address for a few days. Their hospitality has been amazing – they’ve welcomed us with open arms despite the fact they don’t know us at all!

My interview was on Monday, but Jen was going to spend the day trying to see if someone had cancelled so she could take their place and managed to get one on Tuesday after the first phonecall. The ‘interview’ was ridiculous – after being manhandled through security, we were presented with a room closely resembling a post office. A diminutive Indian lady took my papers and checked them, then asked me to sit down and wait… 45 thumb-twiddling minutes later (they’d taken away my phone, MP3 player and any form of entertainment), I was called to a desk by a serious American voice, who simply asked me two questions – where was I going and why was I here? That was it – what a waste of time! But anyways, it’s all sorted, sigh of relief – we’re going to Snowplanet tomorrow to get some practice in.