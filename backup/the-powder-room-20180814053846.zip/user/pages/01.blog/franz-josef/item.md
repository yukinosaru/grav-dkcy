---
# http://learn.getgrav.org/content/headers
title: Franz Josef
slug: franz-josef
# menu: Franz Josef
date: 18-10-2006
published: true
publish_date: 18-10-2006
# unpublish_date: 18-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**18th October 2006**  
*Big Red Internet Bus, Franz Josef*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683650_img_1799.jpg "Jen Ice Climbing")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683650_img_1799.jpg)In a random London bus with internet access in Franz Josef on the west coast, having spent 5 very wet nights here!

Our plan was to arrive, helihike the glacier and buzz on through, but I guess arriving on Friday 13th was never going to be a good sign! Torrential rain, even for the notoriously wet West Coast, flooded the glacier and stopped us from doing anything (again!). It proved to be a blessing in disguise though, cos we decided to stay and sort ourselves out a bit. Found a great hostel (Glowworm Cottages) that was just what we needed to take stock and relax a bit.

Anyways, eventually the rain cleared and Jen and I went ice-climbing on the glacier – absolutely brilliant fun, but tough work! Jen’s got some great photos of us stuck to sheer ice walls! Dead impressed with it all really, me being scared witless of heights and Jen never having done anything like it!