---
# http://learn.getgrav.org/content/headers
title: What time is it?
slug: what-time-is-it
# menu: What time is it?
date: 20-06-2006
published: true
publish_date: 20-06-2006
# unpublish_date: 20-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,new zealand]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**20th June 2006, 11.04 pm**  
*City Central YHA, Christchurch*

Just woken up from one of my numerous spontaneous naps today, terribly confused about what time and day it is, I fear someone has kidnapped Monday.

So it’s apparently Tuesday 20th and I’ve now spent a day in NZ having travelled an unknown amount of miles, surviving LAX where I was scanned, fingerprinted, photographed and screened (all for a fecking transfer!!!), navigating the terrors of Biosecurity in Auckland airport (apparently muddy boots constitute as great a threat to Kiwis as bearded gentlemen wearing bulky jackets do to Americans), then running across said airport to catch my connecting flight due to the incompetence of Qantas making us an hour late.

But I’m in Christchurch now, happily encamped in the City Central YHA. It’s bloody freezing here – a fact that had somehow slipped my attention and taken me totally by surprise as I stepped off the plane. You’d think I’d know better.

Spent most of today wandering around trying to find a car and generally getting lost in ChCh. Nice place, but jetlag is preventing me from appreciating it fully!

Claire’s coming down tomorrow, so we’re going to meet up – nice to have a familiar face around. She’s even been so kind as to offer me a lift to Wanaka – but I’m not convinced I’ll either fit in her car or that it’ll be able to take the weight of all my stuff!!

So there we have it – day one of the adventure. Most of which has been spent in and out of consciousness with my head lolling to one side. Excellent.