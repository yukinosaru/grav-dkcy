---
# http://learn.getgrav.org/content/headers
title: Chanoyu
slug: chanoyu
# menu: Chanoyu
date: 19-02-2011
published: false
publish_date: 19-02-2011
# unpublish_date: 19-02-2011
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [For Tea Too,Itchy Feet]
    tag: [japan,lebenskrankheit,travel,japan,lebenskrankheit,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

0822 Onboard the skyliner to Narita airport

This trip felt different and unexpected. I feel shaken and that something has changed but I can’t tell what. every time I come to japan I feel like I unpeel another later of the onion. There are so many reasons why it’s a frustrating place, so many ways it’s behind the times. Yet theres something here that I can’t quite put my finger on. A sense of outpost, that this is perhaps the last bastion of a former world seamlessly blended with modernity. Or perhaps somewhere in here lies the secret to another way. A better, more satisfying way. Or maybe I’m just romanticising it and falling in love with its exoticism and mystique. Time.