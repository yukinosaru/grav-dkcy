---
# http://learn.getgrav.org/content/headers
title: The road to Beni
slug: the-road-to-beni
# menu: The road to Beni
date: 07-11-2008
published: true
publish_date: 07-11-2008
# unpublish_date: 07-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Early start. Again! But glad to leave Tatopani behind and move closer to Pokhara. A long day, boring because a road has been put in, so a long slog over dusty tracks, avoiding buses and lorries. Some nice moments and sights and fun chats, but by the time we reach Galeshwar, we’re bored and opt for a taxi or bus. One does not appear, so we slog on, eventually finding a taxi and negotiating hard for him to take us 5 mins down the road to Beni. We end up sharing with 2 kids who just stare all the way.

Hopping out at Beni, we avoid taxis and crawl onto a local bus. Exhausted but happy. Long bus ride to Pokhara with a kid on my bag/M’s knee. Finally back to Baglung bus station. Irritable haggling gets us a ride to the Gauri Shankar, sharing with a random Dutch guy who now lives in Spain. Fortunately Judy kept our room and we end up with a much nicer double. Korean food and penny pinching seal the day.