---
# http://learn.getgrav.org/content/headers
title: 2008
slug: 2008
# menu: 2008
date: 13-01-2008
published: true
publish_date: 13-01-2008
# unpublish_date: 13-01-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**13 January 2008, 22.19**  
*Sitting on my bed in Brixton, listening to Gotan Project*

Haven’t blogged for a while and thought I’d give it a go, but somehow I just don’t know how to begin anymore. Thoughts swimming round my head, life on the up, 2007 was Saturn returned big style, but 2008 seems full of hope, promise and opportunity.

Had our Sabb reunion on Friday and it was fantastic to see everyone again – I felt so proud to see how great the Union is and how its really thriving. Being with other Sabbs re-energised me and reminded me of how I used to be. I can’t believe that was 7 years ago. I feel like it was such a high and I’m still looking for a way to get back there. But lots of thoughts have been triggered and are tumbling out around me. I don’t know what this year holds, but I’m finally beginning to feel like I’m coming back to the centre again.