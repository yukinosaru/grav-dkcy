---
# http://learn.getgrav.org/content/headers
title: Heli Heli
slug: heli-heli
# menu: Heli Heli
date: 05-08-2006
published: true
publish_date: 05-08-2006
# unpublish_date: 05-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,snow,travel,new zealand,snow,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**5th August 2006, 18:00**  
*Alpine Resort*

![Arty helicopter shot](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/artyheli.jpg "Arty helicopter shot")![Me and helicopter](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/meandheli.jpg "Me and helicopter")Wow. What can I say? One of the most amazing experiences of my life. After two weeks of waiting, we finally got the go-ahead for heliboarding.

So we bundled onto a coach and headed down to the staging area in crystal clear blue skies, where we were briefed on heli safety and using avalanche transceivers. Then it was onto the heli before being whizzed off to the North Harris Mountains and our first run down pristine powder!

I was in a group with Ryan, Kristine, Nick and a random Taihitian guy called Michael. Laetitia was our guide. We crouched low around a pack as the chopper arrived before cramming into the small 6 seater and taking off.

![Nick, KB and I](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/helicrew.jpg "Nick, KB and I")As we came in to land, we could see the first group setting off and you could feel the adrenalin rise. Seconds later, we were coming in and crouched low as the heli took off. Then there was silence as we peered off into the distance and gathered our kit together.

Laetita gave us a quick brief on snow conditions and headed off – the first run was a little crusty, but still great and a good warm up!

![Reflection in my goggles](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/goggleshot.jpg "Reflection in my goggles")Then we were off again, for a spot of filming – I got a bit over excited in my quest for fresh and lost sight of Laetitia’s tracks, ended up heading down a great line, but realised my mistake about halfway down and had to traverse off to catch her – got a little (and well deserved) telling off, but it was a great line!

We stopped for lunch mid-way through our third run, the guides had dug a little table out and laid out a fantastic spread – better than my normal lunch! Some of the boys got busy building a kicker (a jump for those not up to speed in snowboard parlance) so I took advantage and got ready with my camera. Got into a great position and shot my first ever sequences! Think they worked well, but are a little out of focus (damn!). Will put the photos up when I get a chance!

![Me ecstatically happy](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/thumbsupheli.jpg "Me ecstatically happy")Then it was off again for our last run, all over too quickly, but left with some great memories of a perfect bluebird day, thumbs up and smiles all round – off for a few bevvies tonight upstairs, then out to Woody’s again. This is what it’s all about – love it!