---
# http://learn.getgrav.org/content/headers
title: Heli/No-heli
slug: helino-heli
# menu: Heli/No-heli
date: 25-07-2006
published: true
publish_date: 25-07-2006
# unpublish_date: 25-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**25th July 2006, 18.34**  
*Alpine Resort*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/sunriseattc.jpg "Sunrise over Wanaka")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/sunriseattc.jpg)Finished up today and Kate and Billy rounded us up to tell us we were going heli-boarding tomorrow. Totally stoked (although shattered, so a bit unsure) – but Billy’s just come round to tell us it’s off ð&#159;&#153;&#129; The snow’s rubbish at the moment!

Doh! A little pleased though, cos I really need a rest.

Anyways, the T2 Nitro was good fun, but I really struggled with it off-piste. Not sure if it was my riding or the board, but I’ll blame the latter! A no-no for me then!