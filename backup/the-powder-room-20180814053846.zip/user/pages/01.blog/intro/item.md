---
# http://learn.getgrav.org/content/headers
title: Intro
slug: intro
# menu: Intro
date: 08-12-2004
published: true
publish_date: 08-12-2004
# unpublish_date: 08-12-2004
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

This will eventually be a weblog, once I’ve decided if I’m going to keep a blog and what I’ll focus on with it! Stay tuned…