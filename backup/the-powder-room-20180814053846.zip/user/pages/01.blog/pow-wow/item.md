---
# http://learn.getgrav.org/content/headers
title: Pow wow!
slug: pow-wow
# menu: Pow wow!
date: 22-07-2006
published: true
publish_date: 22-07-2006
# unpublish_date: 22-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,snow,new zealand,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**22nd July 2006, 1800**  
*Alpine resort (surprise!)*

Up the mountain again today – total bluebird day! Pete, Ros and I were going to have a gentle day, but ended up hitting it quite hard in the morning – couldn’t resist really!

Another top day, blasting around – visibility was much better and meant we could actually see what we were riding!

Found some great wind-loaded chutes and had a peek over at Matukituki basin. I’m so pleased with my riding at the moment, it’s really come on since I arrived – was flying down off-piste today in control and without bricking myself! Topped the day off with a hike up the ridge and dropping back into the main basin along Sundance (trail map is at <http://www.treblecone.co.nz/Info/high-res-trail-map.asp>) Just insane powder down there and could see our lines from the bottom! Would never have even thought of doing that 3 weeks ago!

The only thing that’s bothering me is my fitness, my calf muscles were killing me by mid morning! It’s the 7th day in a row that we’ve ridden, so I’m hoping it’s that and a day’s rest will do me wonders.

Still, lots of work to do for Stage 1 – my riding needs to step up a gear if I stand any chance of passing – but we’ll worry about that on Monday!