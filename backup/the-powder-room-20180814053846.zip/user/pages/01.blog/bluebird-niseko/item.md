---
# http://learn.getgrav.org/content/headers
title: Bluebird Niseko
slug: bluebird-niseko
# menu: Bluebird Niseko
date: 05-03-2009
published: true
publish_date: 05-03-2009
# unpublish_date: 05-03-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [dailylife,japan,snow,dailylife,japan,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

[![NISS Instructors at rest](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/img_5915-200x133.jpg "NISS Instructors at rest")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/03/img_5915.jpg)Gorgeous blue sky day today, a real treat here in Niseko! I had my final lesson with Lisa today and had a great time, she’s skiing really well – I’ve really enjoyed skiing together and was sad to see her go.  
 As it was such a great day, we all sat outside and topped up our goggle tans while we ate lunch. Just a really nice spring vibe going on!  
 Didn’t have work after lunch, so hit the park with Matt – perfect conditions, soft snow, warm sunshine. There were quite a few good riders so I grabbed my camera and scoped out the kickers. Found myself a nice spot right by the lip and ended up laying down in the snow as guys whizzed past my ears.  
 Awesome day, topped off by the prospect of 2 days off. Unfortunately the forecast is for rain, but that means we’re gonna head out tonight for a few celebratory drinks instead!  

			#gallery-4 {
				margin: auto;
			}
			#gallery-4 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-4 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-4 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */

 [![](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)   