---
# http://learn.getgrav.org/content/headers
title: Soul Riders
slug: soul-riders
# menu: Soul Riders
date: 24-07-2006
published: true
publish_date: 24-07-2006
# unpublish_date: 24-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**24th July 2006, 22.28**  
*Alpine Resort*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tcviewpoint.jpg "Pete and Roz at Viewpoint, TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/tcviewpoint.jpg)Just got back from the Soul Riders film festival in town, they were showing “91 Words for Snow” – one of my fave films. All about what snowboarding means to lots of pro riders and generally soulful kinda stuff. Really loved it and it’s inspired me to really go for it tomorrow in training – and to top it off, I won a free day pass to Cardrona!

That film always leaves me with a warm feeling – riding’s about having fun with your mates and just being out in the mountains, enjoying nature and the pure and simple feeling of sliding down a mountain on a bit of wood! That’s what we’ve been doing these past few days and I’ve been loving it!

Course wise – we’ve done the CSI now, so the focus is on rider improvement and then on to the level 3 and 4 progressions. Today we were developing our carving (i.e. riding on the edges of the board) and off-piste riding. Lots of work and my legs are killing me, but really pleased with my riding!

Demoing a few boards just to get a feel for different rides – tried a K2 Darkstar today and it was pretty sweet – lots of fun to ride and very playful. A lot more flexible than my Burton Custom and more freestyle oriented. Trying a Nitro T2 tomorrow, which is even more freestyle – not really my cup of tea, but will give it a crack. Then Thursday will be the Option Mendenhaal.