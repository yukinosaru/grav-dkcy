---
# http://learn.getgrav.org/content/headers
title: Settling
slug: settling
# menu: Settling
date: 14-01-2009
published: true
publish_date: 14-01-2009
# unpublish_date: 14-01-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [dailylife,japan,dailylife,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

On my bed at Unitas after ski training

[![Kutchan](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/ktownlocation.jpg "Kutchan location map")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/ktownlocation.jpg)Kutchan



Getting bit more settled now, I live in Hirafu, but made my way over to Kutchan (a nearby town)Â  a few days ago and hit up the Max Valu supermarket – it was heaven for me! Jap food all the way, so stocked up on lots of things and reckon I’ve saved myself a fair whack with that. Food-wise there’s been a definite improvement here, we’re now getting Japanese food twice a week and the other meals have been much better. Still pretty school canteen, but OK.  
 Work’s been good too, had my first lesson this season (a nice English girl who’s just on her way back to the UK from 6 months in Toyko)Â  and been figuring out how the school works. At the moment there doesn’t seem to be a huge amount of work to go round, but it’ll get busier at Chinese New Year. Met up with Tiktak last night, which was cool. Turns out that NISS named our kids program after her. Pretty cool I thought. Been getting to know others at work and feeling quite good about things now. We have training every Monday and Wednesday – so far I’ve just been doing the ski training cos I want to do my Level 2 exam in Feb, but judging by tonight’s performance, I might think twice about that!

[![Jagatakun, Kutchan's town mascot](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/jagatakun.jpg "Jagatakun")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/jagatakun.jpg)Jagatakun, Kutchan's town mascot



Went to Kutchan today to register for my geijin card, a card that foreigners have to get if they stay for more than 90 days – lets me get a bank account etc. Should have one up and running soon. Kutchan Town’s mascot is Jagata-kun – a skiing potato boy?! I kid you not. Kutchan’s main summer produce is potato, so thy thought ‘why not combine the two?’. Because it’s ridiculous, that’s why.  
 Started snowing again today – huge chunks of the stuff falling out of the sky, it’s pretty wet, but crazy to watch. Even after a short chair ride, I was covered in about a centimetre of snow. 30cm is forecast before tomorrow morning. Sweet!