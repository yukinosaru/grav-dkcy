---
# http://learn.getgrav.org/content/headers
title: Dang
slug: dang
# menu: Dang
date: 07-03-2009
published: true
publish_date: 07-03-2009
# unpublish_date: 07-03-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [injury,japan,injury,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Bad day today. Went climbing with Tim and Dylan at the Niseko Adventure Centre (NAC), which was really great fun, but managed to tweak something in my back/hip. It was fine at first, then progressively got worse to the point where I couldn’t walk without excruciating pain shooting thru me. Ended up getting picked up by Ryan and Mimi and driven back to Unitas. Really worrying as it feels like something pretty significant and probably means I can’t work for a while. Maybe even have to come home ð&#159;&#153;&#129;