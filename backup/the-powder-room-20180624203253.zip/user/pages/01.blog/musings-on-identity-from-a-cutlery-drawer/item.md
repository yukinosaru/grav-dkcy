---
# http://learn.getgrav.org/content/headers
title: Musings on identity from a cutlery drawer
slug: musings-on-identity-from-a-cutlery-drawer
# menu: Musings on identity from a cutlery drawer
date: 06-08-2009
published: true
publish_date: 06-08-2009
# unpublish_date: 06-08-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: [dailylife,random,reflection,dailylife,random,reflection]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Today I cleaned out my Mum’s cutlery drawer (yes, that’s right – a tidy cutlery drawer is a mark of civilisation. And too much time on your hands) and found out everything you need to know about what it means to be Chinese. See if you can spot:

– melon baller  
 – curved bi-directional grapefruit knife  
 – broken egg timer  
 – 14 sports-type bottle tops  
 – 3 tea strainers  
 – a curved cheese knife  
 – 14 jam jar lids  
 – 8 assorted Tupperware lids  
 – an angel shaped cookie cutter  
 – 2 ‘Cannies’ closures for open drinks cans  
 – novelty claw shaped crab hammer  
 – 2 cunningly resealable milk bottle tops  
 – a mini-whisk  
 – a pickled onion fork  
 – 1 plastic disposable fork  
 – a medicine dispenser cup

[![Unique utensils](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/08/DSC00534-1024x768.jpg "Random cutlery drawer junk")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/08/DSC00534.jpg)Unique utensils



BUT the highlight was…

– A collection of teaspoons from various world airlines (Left-Right: Thai, JAL, Qantas?, United, Continental, British Airways, Qantas. On the top: Malaysian,  
 Singapore Airlines)

[![Teaspoons from various airlines](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/08/DSC00536-200x150.jpg "Airline cutlery")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/08/DSC00536.jpg)Teaspoons from various airlines



Cultural heritage in a cutlery drawer. Fantastic.