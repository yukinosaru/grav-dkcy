---
# http://learn.getgrav.org/content/headers
title: Some other beginning&#8217;s end
slug: some-other-beginnings-end
# menu: Some other beginning&#8217;s end
date: 13-06-2009
published: true
publish_date: 13-06-2009
# unpublish_date: 13-06-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race,凄いですね (sugoi desu ne)]
    tag: [japan,lebenskrankheit,reflection,sustainability,japan,lebenskrankheit,reflection,sustainability]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

[![New shoots](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/06/20090430_6970-133x200.jpg "Tulips by Lawson")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/06/20090430_6970.jpg)New shoots



Well I’ve been here in Japan for 5 months, the last 2 of which have been trying to sustain myself over the summer both financially and spiritually. And on both counts, I think it’s time to call it a day. I’ve decided to head back to the UK, temporarily, but depending on a few things, possibly for longer.

On reflection, at times, this has felt like a retreat, giving me space and perspective on the maelstrom of thoughts that filled my world (at other times, it’s been quite the opposite!). But now, I feel like Rabbit has finally stopped talking and I’m beginning to hear those 12 pots of Hunny calling me.

I can no longer hide from the little nagging voice in my head that speaks of our interconnectedness and moral imperatives. As a good friend once said “I’ve stepped in my conscience and I can’t seem to shake it off”. I want to contribute, play my part in what is an exciting time for the world. And now I feel ready to return to more direct efforts to make this world a better place, armed with a clearer sense of direction – I’m ready to channel my energy and experience into something bigger than myself.

I still yearn to live in the mountains and continue to grow as a snowboarder, but I’m confident that will resurface in future, probably in a different form. I’ve spent the last 5 years juggling two worlds, and perhaps now is the time to keep my eye on the other ball.

So, where in the world does this put me? Well, I came here seeking a better quality of life and found it in some ways. But I miss my friends, my family, my community. They’re all part of a well-balanced life and contribute to a sense of belonging, of meaning. I love meeting new people and discovering new places, but I miss some of the mundane, routine things that made up my life in London and I miss hanging out with old friends. So that points to being back in the UK again, but at the same time I’m still not ready to fix myself in the UK and there’s a world of opportunities out there. So time will tell as to where I end up (no surprises there then!).

[![Douzo](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/06/20090521_7545-200x133.jpg "The road ahead")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/06/20090521_7545.jpg)Douzo



Some may see this decision as turning back, giving up. Or as indecision, caught between two worlds. Perhaps it is, and maybe I’m trying to create grander purpose behind my decisions or explain myself somehow, but it feels different to me.Â  To me it feels like a new phase of my life, moving forward, evolving, beginning.