---
# http://learn.getgrav.org/content/headers
title: Slidin&#8217; on
slug: slidin-on
# menu: Slidin&#8217; on
date: 07-07-2006
published: true
publish_date: 07-07-2006
# unpublish_date: 07-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**7th July, 19.47**  
*Unit 15a, Alpine Resort – borrowing my housemate Danny’s laptop*

So there we have it – week 1 of the course – awesome and tough, but fantastic. Spent most of it focussing on stance, alignment, body movements and board performance concepts (how the board moves) – all stuff that we have to teach and demonstrate in 10 days time for our Certificate in Snowsports Instruction (CSI) exam!

It’s been a really great week and Jim is a fantastic trainer, I feel like my riding has improved tenfold in the three days we’ve had riding with him.

We had a few runs down the off-piste in the Saddle Basin and I made it all the way down under control and without falling – compared to last Friday when I spent most of my time in the Saddle sideslipping or on my butt!

I’ve also boosted my switch riding – we had a great exercise today where we had to hop whilst turning, was fab for dropping the stance, centering balance and relaxing – feel much better about it now.

We had our first video session today, where we were all filmed and had some movement analysis – I was really pleased with it, my riding was much better than I expected and there’s still some stuff to work on, but nothing I didn’t already know – it was just great to actually see it and visualise what I needed to do to correct it. Basically, I need to focus on pushing my shin right into my boot and down to the board when turning toe-side – had a practice in the afternoon and feel like it’s coming along nicely!

Had my first swiss ball class too – wasn’t too bad, but was working all the right muscles, cos they were feeling it today!

We’ve got our first aid course this weekend, then just need to focus on riding, teaching progressions and getting through the exam!