---
# http://learn.getgrav.org/content/headers
title: O say can you see
slug: 
# menu: O say can you see
date: 18-11-2016
published: false
publish_date: 18-11-2016
# unpublish_date: 18-11-2016
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

A tribute to a former time of internationalism and hope. Of pride in persevering against the odds and coming through.  
 A military anthem celebrating a British defeat – played at the Changing of the Guards.  
 As a symbol of protest, a reminder of what makes America great.

At this, another punctuation mark in the great history of America and the world.  
 The star-spangled banner in triumph shall wave  
 O’er the land of the free and the home of the brave.