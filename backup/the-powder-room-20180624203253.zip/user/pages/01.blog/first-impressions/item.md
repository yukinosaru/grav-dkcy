---
# http://learn.getgrav.org/content/headers
title: First impressions
slug: first-impressions
# menu: First impressions
date: 09-01-2009
published: true
publish_date: 09-01-2009
# unpublish_date: 09-01-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,japan]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Sitting in a dark corner of the dining hall at Unitas  
 Arrived. Took 30 hours. Got stuck in Hong Kong. We piled onto the plane, only to sit there for an hour an then be told the plane was broken. Not such a problem, but slightly worrying given that it was the plane I’d just sat on for 11 hours from London!  
 Met a nice Aussie family on the bus and chatted away. The bus took a brief stop at a 24 hour toilet and I got to experience the delights of a heated toilet seat. On the way back out, there was a vending machine selling coffee and hot chocolate in cans! The best invention ever! Sat at the back of the bus drinking hot coffee and grinning smugly.  
 Arrived at Hirafu late (about 10.30pm) and was met by Kate (one of the ski supervisors), who took me to my accommodation in Unitas, where I met Francis, a friendly Singaporean guy that lives in Australia and is my new roommate. The room is small, but cosy – it’s basically a log cabin.

![Yotei-san from Hanazono](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/01/dsc00421-200x150.jpg "Yotei-san")Yotei-san from Hanazono



After getting a half-decent night’s sleep, I hopped on the free bus and spent today exploring the mountain. Niseko is divided into 4 areas, from West to East: Ann’puri, Niseko Village (renamed from Higayashima), Hirafu and Hanazono. I’ll be working at Hanazono and Hirafu. It’s a medium sized place, easy to get around and looks like a good place to learn and to teach. It hasn’t snowed for a few days, so it’s surprisingly scratchy in places – but I found some trees on the leeward side that had held the windblown snow. Was nice to dust off my snowlegs – although my first few runs were a bit ropey!  
 Rather randomly bumped into Sam and Sara at breakfast – Sam worked at Winter Park with me and Sara joined him the year after. Was nice to see some familiar faces, which took the edge of the scary loneliness!  
 Food is an interesting challenge here – I was really looking forward to lots of yummy Japanese food, but my (expensive) rent includes food here, which is basic, stodgy Western food :(. At lunch I had an explore and found that most places cost an absolute fortune and the food didn’t look that great. But I found Seicomart (a supermarket type place) and they had triangular rice ball things for 100 yen (less than a quid). I put my hiragana skills to the test and did quite well in deciphering the labels. Wasabi-nori for me then. It’s a little frustrating to not have a kitchen, cos I reckon you could eat well very cheaply here by buying fresh food from Seicomart and cooking it yourself. I’m sure I’ll figure something out – have already bought miso and genmaicha!  
 So I’m here now. It’s not quite what I expected, but then what did I expect? I’m feeling a little worried and lonely, but I’m sure it’s just a matter of time before I get settled and find out all the little hidden gems!