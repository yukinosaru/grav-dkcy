---
# http://learn.getgrav.org/content/headers
title: Pandora&#8217;s box
slug: pandoras-box
# menu: Pandora&#8217;s box
date: 18-07-2008
published: true
publish_date: 18-07-2008
# unpublish_date: 18-07-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: [lebenskrankheit,lebenskrankheit]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

I haven’t blogged in a while as life seems to have taken over again, but this picture pretty much sums up how I’m feeling at the moment.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/balloongirl_alwayshope-300x207.jpg "Banksy Picture")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/balloongirl_alwayshope.jpg)

Thanks Banksy