---
# http://learn.getgrav.org/content/headers
title: Alpine Resort
slug: alpine-resort
# menu: Alpine Resort
date: 01-07-2006
published: true
publish_date: 01-07-2006
# unpublish_date: 01-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**1st July 2006, 18.30pm**  
*Alpine Resort, Wanaka*

Moved into our accommodation for the season, after a pretty unsettled first day and a bit of a wobble, feeling much more at home now and beginning to get some sense of routine.

We moved in two days ago and I was having a pretty down day – I felt unsure why I’m doing this, was worried that my boarding wasn’t up to scratch and didn’t find the apartments particularly homely, especially after the lovely Mountain View Backpacker.

But a new morning and a great day’s riding soon snapped me out of that and I’m feeling much more buoyant now. I think I just need to remember why I’m doing this and to focus on me, not on what everyone else is doing.

We hiked up Mount Iron today, hard work, but [great views](http://www.dkcy.com/photography/collection.php?colid=24). It was billed as a social thing, but I got the feeling it was Dean’s way of sussing out our fitness!

Really missing Jen, so have been listening to lots of music and thinking of her (big kiss X – yeah, yeah, soppy to anyone else reading, but does it look like I care?). Time will fly by and I can’t wait till she gets to see this place!