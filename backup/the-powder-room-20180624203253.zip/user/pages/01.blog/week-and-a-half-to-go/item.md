---
# http://learn.getgrav.org/content/headers
title: Week and a half to go
slug: week-and-a-half-to-go
# menu: Week and a half to go
date: 09-08-2006
published: true
publish_date: 09-08-2006
# unpublish_date: 09-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**9th August 2006, 13:47**  
*Alpine Resort, sitting outside in the sun*

Day off today, but decided not to go up the mountain – feeling crook again, some sort of cold thing, need a day’s rest methinks. Anyways, this week has been better, we’ve swapped groups again, this time I’ve got Dan as our trainer in a group with Chew, Jen and James. We’re working on the teaching element again, which I think I’ve got a good grasp of and really quite enjoying. Feel like my freeriding has improved and I’m beginning to address my heelside problem, but really need to work on my freestyle. We had our introduction to movement analysis the other day, this is the core of instructing and is about spotting where people are going wrong and figuring out how to explain it and correct it. I seemed to get on OK with is, so fairly relaxed on that front – got a week and a half to go before the Stage 1, so just need to focus on riding.

On the job side, I’ve been lined up to go to Winter Park (in Colorado, USA), but still struggling to find jobs for Jen. Spoke to the team from Snowshoe Mountain, which was the most promising resort, but alas, they don’t have any jobs for Jen – the problem is to do with visas, basically we need a H2B visa and the jobs that we’d seen were for US citizens.

There are some H2B jobs at Winter Park, so we’ll see how those go. I’m sure it’ll all work out somehow and someway.