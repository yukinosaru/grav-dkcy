---
# http://learn.getgrav.org/content/headers
title: Time to stand and stare
slug: time-to-stand-and-stare
# menu: Time to stand and stare
date: 10-09-2006
published: true
publish_date: 10-09-2006
# unpublish_date: 10-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,new zealand,snow,travel,instructing,new zealand,snow,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**10th September 2006, 22.38**  
*In bed*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/melookingattc.jpg "Me looking at TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/melookingattc.jpg)My quest for space took me up Mount Roy today. It’s been ages since I’ve done any proper walking, so it was quite a nostalgic relief to go up the side of a mountain.

Mount Roy (or Roy’s Peak) is at around 1500m, so is over 1000m above the road – pretty vertiginous climb, steep switchbacks snaking all the way up. It took Kev and I nearly 3 hours to get up (via a small diversion into some prickly tussock – oops!). The views were spectacular – right the way down the Matukituki river to Mount Aspiring, over to Treble Cone and right back over to Wanaka. Couldn’t have asked for better weather – clear blue sky and not a breath of wind in the air.

As we reached around 1200m, we hit the snowline and had to dodge the odd patches of spring snow. Right up the very top, we were forced to trudge through snow to climb the last few metres up the ridgeline.

I was supposed to be having a rest day before BASI, but I’m glad we went. I needed to get out there and do something (not that I don’t do that on a daily basis, but you get what I mean).

I’m looking forward to starting the exam tomorrow – not sure how I feel, don’t feel worried as it feels just like another week of training. Well, we’ll see how it goes. I feel much more confident about my riding (and feel that I’m now riding like a Stage 1 qualified instructor!) and the teaching is pretty much the same, so am quietly upbeat about it. I’ve just got to focus and consistently show that I can do it.