---
# http://learn.getgrav.org/content/headers
title: 
slug: 913
# menu: 
date: 29-05-2009
published: false
publish_date: 29-05-2009
# unpublish_date: 29-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Feeling lost again today. No idea what I’m doing – no meaning to my daily existence. Cooking is good cos it gives me purpose and a distraction, then I eat, then I don’t know what to do. Fill my time with games, poker, facebook and random internet – what sort of existence is that?

But I face the same problem even when I am gainfully employed – I have spare time in the evenings and weekends. What do I do with them? Before I think I just recovered from work – is that a meaningful existence?