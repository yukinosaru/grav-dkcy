---
# http://learn.getgrav.org/content/headers
title: How true is &#8220;Yes, Minister&#8221;?
slug: how-true-is-yes-minister
# menu: How true is &#8220;Yes, Minister&#8221;?
date: 08-07-2014
published: true
publish_date: 08-07-2014
# unpublish_date: 08-07-2014
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![](http://www.yes-minister.com/images/oth_ypmstill3.jpg)

  Alan Budd recently blogged an elaboration of a comment he made on Martin Donnelly’s speech on the civil service. It triggered a Twitter exchange between myself, Alex Evans and Jill Rutter…  
[[View the story “How true is “Yes, Minister”?” on Storify](//storify.com/YukiNoSaru/how-true-is-yes-minister)]