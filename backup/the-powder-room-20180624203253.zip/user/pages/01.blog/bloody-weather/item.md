---
# http://learn.getgrav.org/content/headers
title: Bloody weather!
slug: bloody-weather
# menu: Bloody weather!
date: 02-08-2006
published: true
publish_date: 02-08-2006
# unpublish_date: 02-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/peteatdl.jpg "Pete at Wanaka Viewpoint")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/peteatdl.jpg)**2nd August 2006, 21:00**  
*Alpine Resort, stuffed to the brim with risotto*

So, heli was cancelled today (again!), but we all went for lunch instead – had a  
 full breakfast to nurse my hangover! Then Maria, Pete and I headed back to Diamond Lake and walked past it this time to a really nice viewpoint

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/mandiatdl.jpg "Maria and I at Wanaka Viewpoint")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/mandiatdl.jpg)Had some food (bit too much actually!) and now sitting around sipping a little local wine. Bit worried about tomorrow cos we need to prove outselves this week so that we can do both exams and I’m a little ropey at the moment – still, must think positive and will be fine!