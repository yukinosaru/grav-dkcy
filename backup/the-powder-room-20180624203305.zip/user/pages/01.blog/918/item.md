---
# http://learn.getgrav.org/content/headers
title: Inspiration
slug: 918
# menu: Inspiration
date: 30-05-2009
published: true
publish_date: 30-05-2009
# unpublish_date: 30-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Now that’s the sort of movie I want to make. Love it.

[Stuff I shot in 2001-2002](http://vimeo.com/4837638) from [pierretube](http://vimeo.com/user1608115) on [Vimeo](http://vimeo.com).