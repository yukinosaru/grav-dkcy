---
# http://learn.getgrav.org/content/headers
title: I passed!
slug: i-passed
# menu: I passed!
date: 27-08-2006
published: true
publish_date: 27-08-2006
# unpublish_date: 27-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**27th August 2006, 19.26**  
*On my bed, in a state of shock!*

I’m sitting here with a piece of paper that says “Standard Achieved” and I can’t quite believe it. I passed – somehow. I don’t think I deserved to, my riding was not up to scratch, but Greg (our examiner) felt it was and felt that all I needed was more mileage.

I should be ecstatic, but I’m not – I feel like it was a little unfair. I don’t think I deserved to pass, yet others didn’t pass and definitely deserved to. I feel like luck had a bit too much of a role to play in this.

Anyway, I’m off out to celebrate with some champagne and pizza – I’ll write a proper entry tomorrow!