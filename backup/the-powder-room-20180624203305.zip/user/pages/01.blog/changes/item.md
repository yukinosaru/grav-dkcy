---
# http://learn.getgrav.org/content/headers
title: Changes
slug: changes
# menu: Changes
date: 11-12-2008
published: true
publish_date: 11-12-2008
# unpublish_date: 11-12-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Old boys playing checkers in Singapore](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081202_5605-200x300.jpg "A closely watch game of checkers in Singapore")A fitting metaphor...



OK, so in case you havenâ&#128;&#153;t noticed, I’ve changed my website! Itâ&#128;&#153;s a bit more streamlined now and you can comment on blog entries too.

I’ve had the site for a while and what started as a sandbox for messing around with web technology and design has mutated into a slightly navel-gazing blog. So I thought I’d update it to reflect that – but also have a think about why I have this site in the first place.

I guess it’s been partly to keep people up-to-date with the maelstrom of my life, but also was a vent, an outlet for voice. Given the way I look at life, it’s ended up being quite ponderous and introspective/angsty, which is fine (aside from convincing my parents that I’m either a) on drugs or b) losing my marbles), but I want to include more of the mundane too in an attempt to dispel the impression that I’m just an angst-ridden hermit (for right or wrong!).

So, what is it now? Well, I’m gonna try and embrace the blogging tradition (is it one yet?) and blog more regularly, hopefully with slightly less esoteric updates and more trivial blatherings from my abstract mind.