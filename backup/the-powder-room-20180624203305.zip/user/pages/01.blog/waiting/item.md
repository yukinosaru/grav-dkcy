---
# http://learn.getgrav.org/content/headers
title: Waiting
slug: waiting
# menu: Waiting
date: 04-04-2006
published: true
publish_date: 04-04-2006
# unpublish_date: 04-04-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [lebenskrankheit,lebenskrankheit]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**4th April 2006, 15:24.**  
*The faithful desk in Ashdown House. Slightly clearer now that Iâ&#128;&#153;ve spent an hour procrastinating and tidying it up.*

With 50 working days to go before I leave this place and fly out to New Zealand, how am I feeling?  
 In a word mixed. In a few more – Scared. Confused. Excited. Expectant. Bored. Unsure. Doubting.

Iâ&#128;&#153;m bored of where I am now, the subject is interesting, but Iâ&#128;&#153;m feeling a little worn out and lacking in motivation. It feels like itâ&#128;&#153;s time to move on, to experience something new and to explore what I want to do and where I want to be.

But it still feels quite risky to do that â&#128;&#147; Iâ&#128;&#153;m leaving career momentum, opportunity and certainty behind. Itâ&#128;&#153;s only for a few months, but I guess Iâ&#128;&#153;m scared Iâ&#128;&#153;ll regret it, that Iâ&#128;&#153;ll have handicapped my potential or my future by this.

As a result or possibly contributing separately, Iâ&#128;&#153;m beginning to feel unsure about this and whether it really is something that I really want to do. Iâ&#128;&#153;m not in the right physical shape at the moment and Iâ&#128;&#153;m not particularly driven to get myself back into shape. Iâ&#128;&#153;m not sure if I can afford it or whether thereâ&#128;&#153;s something else I would rather spend that money on. Iâ&#128;&#153;m worried about what it will mean for my relationship. Iâ&#128;&#153;m worried that it wonâ&#128;&#153;t be this amazing life-changing experience â&#128;&#147; thatâ&#128;&#153;ll itâ&#128;&#153;ll just be a few months dossing about and then Iâ&#128;&#153;ll come back, maybe a bit fitter, a bit better at snowboarding, but essentially no different. Iâ&#128;&#153;m scared that Iâ&#128;&#153;ll go on this journey and find itâ&#128;&#153;s a dead end, so then I have to retrace my steps and pick up my life from where I left it. Maybe Iâ&#128;&#153;m just trying to prove a point and rebelling for the sake of it.

Basically, I feel like I donâ&#128;&#153;t know what the hell Iâ&#128;&#153;m doing anymore and Iâ&#128;&#153;m beginning to doubt my instincts.

But then again, isn’t that why I’m doing this?