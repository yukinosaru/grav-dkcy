---
# http://learn.getgrav.org/content/headers
title: Preparations
slug: preparations
# menu: Preparations
date: 09-05-2006
published: true
publish_date: 09-05-2006
# unpublish_date: 09-05-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**9 May 2006, 11:12.**  
*Guess where?*

So, 21 working days to go and I can't wait. Feeling exhausted with work and really struggling to keep motivation up. In a way, it's positive, cos it's clearly time for me to move on now. But I'm torn between a feeling of apathy and frustration at myself, mixed with a mild sense of panic at the volume of work I need to do. But enough navel gazing and soul-searching…

On the preparation front, I seem to be spending money like mad – just bought some second-hand boots (Burton Hail, Â£85) and some new bindings (Burton Cartel, Â£120), plus I reckon I'm going to need some padding and a helmet. But seriously stoked about the trip – itching to strap on my board and go riding!

Fitness-wise, I've started capoeira – it's been great fun and I can't believe it's taken me so long to get into it. I guess fear and self-consciousness got in the way! Anyways, I've started now and am hooked – it's just like being a kid again, you get to cartwheel around, rolling over and generally playing. Plus it's a really sociable bunch of people – the group's website is <http://www.capoeiraworld-uk.com/main.html>. The only thing I would say is that I'd prefer more instruction, it's a little daunting when you first start and don't know any of the names of the moves or how to do them, yet are expected to roll a load together. The group is going to be split into two now, with beginners separate from others, so hopefully it can be a bit more supportive for us lamers!