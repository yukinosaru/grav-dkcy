---
# http://learn.getgrav.org/content/headers
title: 
slug: 903
# menu: 
date: 25-05-2009
published: false
publish_date: 25-05-2009
# unpublish_date: 25-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

just back from fixing PDF problem for Maru Asobi. Maybe it’s the sunshine, maybe the walk, maybe the sense of achievement at doing something in Japanese, but I feel more positive right now. Feel like I should accept that I’m in a pit, that I should put all of this aside and focus on healing myself. Feels like I should take control of my life – Saturn return doesn’t make anything happen, I need to make decisions. Feels like I should go home, put my affairs in order, see a shrink, exercise, see my friends, save money. Then and only then should I worry about the mountains, or michelle, or what I’m doing with my life.

That’s what I feel right now and I feel energised to do that. But at the same time, there’s a thought in my head that says this feeling will go shortly and then I’ll feel doubly confused and back at square one.