---
# http://learn.getgrav.org/content/headers
title: Instructor Dan!
slug: instructor-dan
# menu: Instructor Dan!
date: 21-07-2006
published: true
publish_date: 21-07-2006
# unpublish_date: 21-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**21 July 2006, 1800**  
*Alpine Resort… I think*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/csi-certificate.jpg "CSI Certificate")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/csi-certificate.jpg) Passed my CSI yesterday!! Hurrah! I’m now an NZSIA instructor – fantastic! (was in no fit state to blog yesterday, hence the delay!) Exam went well, had to teach garlands for my assessment and all was good although i had a total brain freeze when Paul asked me about how I would change the lesson for kids!

So had a damn good blast around Cardrona to celebrate, down Arcadia chutes and generally catching some great snow. The sun was out and all was fantastic! All topped off with a cheeky drink at the Cardrona Hotel and a few glasses of champagne – top night (but the less said the better – drainpipe).

Today was back to training, total whiteout conditions, but fantabulous snow – loads of powder. My legs were really not up to it in the morning, but soon warmed up after a run down Gun Barrel (a gully run that’s pretty hard work).

Basically had a free day, went up with Kate (trainer), Kiwi Pete, Nick and James – top stuff, really great windblown pockets. Tried a few jumps and drops! No injuries luckily!

The afternoon was even better, hooked up with Billy and Tom’s group and had a big crew riding around the mountain! Loads of fun stuff – easily the best day riding I’ve ever had!

They totally rode us into the ground and by 3.30 was barely standing – but chuffed to bits!