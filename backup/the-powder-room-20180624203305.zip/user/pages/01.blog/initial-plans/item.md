---
# http://learn.getgrav.org/content/headers
title: Initial Plans!
slug: initial-plans
# menu: Initial Plans!
date: 09-02-2006
published: true
publish_date: 09-02-2006
# unpublish_date: 09-02-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [travel,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Right! Been down to STA travel to look at flights and how the bleeding hell I get to NZ and back again. After a bewildering array of options (and after consulting with her indoors!) I’ve decided to go for a flight out via LA and returning via Fiji and possibly LA.

Our cunning plan is to spend about a month in NZ after my course, probably driving around in a camper van. Then to head off to Fiji for a couple of weeks, then to LA.

From there, was thinkin about driving coast-to-coast to NY – classic American road-trip! Can’t say that the USA is particularly high on my list of places to go, but driving across the States would be awesome (if a little heavy on emissions!).