---
# http://learn.getgrav.org/content/headers
title: Shadowing
slug: shadowing
# menu: Shadowing
date: 25-09-2006
published: true
publish_date: 25-09-2006
# unpublish_date: 25-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**25 September 2006, 1920**  
*At home*

It’s been a funny few days. Now that we’ve finished, I’m at a bit of a loss as to what to do with myself. We had a good night out on Friday and a final Rookie get-together on Saturday, but I felt strangely detached from it. Felt like a bit of an anti-climax (again). Sure, I’ve enjoyed this and met some great people, but it just doesn’t feel like the end of a major occurrence. I think I need to rest and let it all sink in.

Went up the mountain on Sunday and regretted it, the Saddle lift was shut and I was just tired. I ended up renting some skis and having a blast around, which was good fun, definitely need to get some proper lessons though!

Spoke to Tim Williams, the snow school director, about shadowing some lessons a while ago. He seemed quite amenable to the idea, but the past few days, there haven’t been enough lessons going up. But today, I managed to shadow Bronnie’s level 3 lesson and ended up taking one of the clients on my own. Seemed to go well, she had fun and didn’t hurt herself! Managed to get her down Easy Rider by lunchtime. Then spent the afternoon riding in the Saddle, hitting the park – managed to land a few kickers, so result all round today.

Still, feel a bit funny though – not really sure what it is, tired, lonely, lost, bored, down. Dunno really – going to the cinema tonight, then will spend tomorrow packing stuff up and getting ready to move out of here.