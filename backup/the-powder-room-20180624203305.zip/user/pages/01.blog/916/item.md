---
# http://learn.getgrav.org/content/headers
title: 
slug: 916
# menu: 
date: 30-05-2009
published: false
publish_date: 30-05-2009
# unpublish_date: 30-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Feeling of drifting through life. Now that’s fine and dandy when you’re in a job and just drifting along, but cos I’m effectively not working, it’s doubly difficult. But getting a job doesn’t solve the underlying problem of feeling like life is just happening. Perhaps it’s a good step to get myself on my feet a bit more and stronger mentally.

Am thinking I need to decide what I’m doing here – leaning towards going home – perhaps in mid June, then Bangladesh for a week, before flying home. Could ship all my crap home now and just travel light. If I get the Alert job, then that’s grand, otherwise I can always go for Be at One. While I’m in Bangladesh I can meet a few people and see the lay of the land. Would be a shame to not be here for winter – but can always come back on holiday. Besides, there’s plenty of other places to see – still haven’t hit europe yet.