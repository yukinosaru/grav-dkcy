---
# http://learn.getgrav.org/content/headers
title: Big crunch
slug: big-crunch
# menu: Big crunch
date: 28-07-2006
published: true
publish_date: 28-07-2006
# unpublish_date: 28-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**28th July 2006, 22.49**  
*Alpine Resort – in bed with sore knees*

New group again today – with Jim again and Pete, Claire, Kristine and Steve – good crew and glad to have Jim as a trainer. All the 13 week boarders were together for the first few runs and we had a bit of video. Jim explained that they’re taking stock of our riding now with a view to assessing our suitability for doing the dual NZSIA/BASI qualification.

Bit of a key point then, if the trainers don’t feel we’re up to it, then they’ll recommend that we focus on one qualification only – mixed feelings about that – I’d be gutted to not do both, but then it would be nice to have just one focus. Anyway we’ll see how things pan out.

The other big crunch I had today was trying some freestyle – hitting a kicker and trying a box. Both went abysmally wrong and ended up knee planting twice in quick succession. What made it worse was that Jim caught it all on video – certainly the most interesting and cringe-worthy feedback session I’ve had!

Still, I know what went wrong and was so close to pulling both off. I’m determined to nail them by the end of the season!