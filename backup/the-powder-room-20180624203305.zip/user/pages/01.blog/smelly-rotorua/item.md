---
# http://learn.getgrav.org/content/headers
title: Smelly Rotorua!
slug: smelly-rotorua
# menu: Smelly Rotorua!
date: 06-11-2006
published: true
publish_date: 06-11-2006
# unpublish_date: 06-11-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**7th November, 11.01am**  
[*Cosy Cottages Holiday Park, Rotorua*](http://cosycottage.kiwiholidayparks.com/ "Link to Cosy Cottages website")

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2068.jpg "Trees in Rotorua")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2068.jpg)Ah, the stench of sulphur – now that’s the New Zealand I remember! We’re just a few miles away from Tokoroa where Dad worked for a while and we all came out to visit.

On the drive up from Taupo, we stopped off at Butcher’s Pool, a tiny little locals geothermal spa pool that’s just south of Reparoa. It was brilliant, really quiet and no tourists for a change! Enjoyed a long soak and chatting to a few locals, and what’s best is that it was totally free!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2087.jpg "Champagne Pool")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2087.jpg)Went off to [Wai-O-Tapu](http://www.geyserland.co.nz/ "Link to Wai O Tapu website") thermal park yesterday and nearly passed out at the stench! Pretty spectacular though – I’d been to another volcanic area when we were here, but I don’t remember it being as colourful as Wai-O-Tapu. We’re in a cosy holiday park with natural geothermal pools and a hangi – basically a steam cooker powered by natual steam. So I bought us some lamb and popped it in the hangi with potatoes, garlic and veg – about 5 hours later, it was ready and the meat just fell off the bone – yum! Gonna try something else tonight methinks.

Next stop is Raglan to see Nicky – we’ve landed on our feet there, cos her friend’s place needs housesitting for a couple of nights – it’s only a $1,000,000 property!! All we have to do is look after the dogs. Result!