---
# http://learn.getgrav.org/content/headers
title: Kumbh Mela
slug: kumbh-mela
# menu: Kumbh Mela
date: 25-04-2010
published: true
publish_date: 25-04-2010
# unpublish_date: 25-04-2010
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [For Tea Too,Itchy Feet]
    tag: [india,lebenskrankheit,reflection,travel,water,india,lebenskrankheit,reflection,travel,water]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Been struggling to write about my experience of the world’s largest act of faith, Kumbh Mela. So much to say that I don’t know how to start. In the meantime, here are some pictures.

![](http://user47216.vs.easily.co.uk/wp-content/uploads/2010/04/kumbh-1024x139.jpg "Kumbh Mela")An estimated 5 million people took a dip in the Ganga on Mesha Sankranti Shahi Snan



 
			#gallery-5 {
				margin: auto;
			}
			#gallery-5 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-5 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-5 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		 [![](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)](http://www.dkcy.com/20081110_4682/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)](http://www.dkcy.com/20090430_6897/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)](http://www.dkcy.com/20090430_6911/)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)](http://www.dkcy.com/20090507_6996/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)](http://www.dkcy.com/20090507_7000/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)](http://www.dkcy.com/20090507_7003/)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)](http://www.dkcy.com/20090507_7009/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)](http://www.dkcy.com/20090507_7010/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)](http://www.dkcy.com/20090507_7011/)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)](http://www.dkcy.com/20090507_7014/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)](http://www.dkcy.com/20090516_7373/)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)](http://www.dkcy.com/20090521_7538/)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)](http://www.dkcy.com/20090521_7540/)   