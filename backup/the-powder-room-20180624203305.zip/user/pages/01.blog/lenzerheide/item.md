---
# http://learn.getgrav.org/content/headers
title: Lenzerheide
slug: lenzerheide
# menu: Lenzerheide
date: 01-02-2010
published: true
publish_date: 01-02-2010
# unpublish_date: 01-02-2010
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [powder,snow,switzerland,travel,powder,snow,switzerland,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Just back from a great week at Lenzerheide in Switzerland. A picture paints a thousand words, so here’s a video – thanks for an awesome week to Jason at [Snowmotions](http://www.snowmotions.com) and Pete at [Alpine Rides](http://www.alpinerides.com). Music is by [The New Governors](http://www.thenewgovernors.com).