---
# http://learn.getgrav.org/content/headers
title: Home for 3 months!
slug: home-for-3-months
# menu: Home for 3 months!
date: 25-06-2006
published: true
publish_date: 25-06-2006
# unpublish_date: 25-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**26th June 2006, 09:37**  
*Bits and Bytes Internet Cafe, Wanaka!*

Well, the weather cleared – but only on Sat – when we were leaving for Wanaka!!! Sod’s bloody law! But the drive from Christchurch made up for it, just totally blew me away. I really feel like I’ve arrived now!!

Drove out from Christchurch (with Matt and Saul in tow) and down State Highway 1, with the Southern Alps and Arthur’s Pass to the right. Stopped in Geraldine to regroup and eat, before heading off up route 8 through the heart of Mackenzie County and our home for the winter.

We climbed up through the mountains, with Doris struggling valiantly, but making it. Over Burke’s pass it was all a bit murky, but then suddenly Lake Tekapo popped up and I nearly sent Doris off a cliff with surprise. Was stunning, so we stopped for a few photos and to soak up the views (although in the excitement I dropped my camera and smashed the polariser!), will post some later.

Matt and Saul cracked us up with a bit of HackJam, their hackysack video – they’re like Bert and Ernie, thoroughly entertaining!

Having had our fill and swelling with excitement, we clambered back into Doris and headed off, only to be hit by the next sight, Lake Pukaki, which was even bigger and more spectacular.

Onwards to Twizel and a quick fuel stop before heading off up route 8 on our last stretch to Wanaka

We arrived in Wanaka at around 6ish and after driving around hopefully, we gave in and asked for directions to the hostel – Mountain View backpackers – nice little place (even if the showers are a bit ropey!!), full of Rookies!

So there you have it. We’ve arrived at the place we shall come home for the next 3 months. And it’s everything I hoped it would be and more!