---
# http://learn.getgrav.org/content/headers
title: Exams!
slug: exams
# menu: Exams!
date: 11-07-2006
published: true
publish_date: 11-07-2006
# unpublish_date: 11-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**11th July 2006, 17.36pm**  
*Unit 15a, Alpine Resort – on my whizzy new Macbook*

Having a rubbish week – we’ve swapped trainers now (we’ve got BASI Tom) and started working on our carving – I just can’t seem to get the hang of anything this week – really frustrating! Especially as our exam starts on Monday

Today was a bit better, relaxed a bit so things flowed more. Doesn’t help that i’ve pulled something in my left hand side and it’s causing me a bit of pain everytime I bend!

Did a spot of buttering (spinning around on the nose/tail of the board) and finally got the hang of getting my nose out of the snow and wheelieing – determined to butter properly by the end of the month.

We’ve got a day off tomorrow, but I think I’m gonna hit the slopes to build my confidence back up and practice what I’ve learnt over the last few days.