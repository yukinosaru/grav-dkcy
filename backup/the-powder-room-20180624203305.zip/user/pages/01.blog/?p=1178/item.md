---
# http://learn.getgrav.org/content/headers
title: Rio+20 = 192 UN Member States = 1 big state
slug: 
# menu: Rio+20 = 192 UN Member States = 1 big state
date: 03-04-2011
published: false
publish_date: 03-04-2011
# unpublish_date: 03-04-2011
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race,Water, water everywhere]
    tag: [climate change,global governance,lebenskrankheit,rio+20,UN,climate change,global governance,lebenskrankheit,rio+20,UN]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

New paradigms

Need to find a new way of international relations.

Transcend national interest.

Means finding more effective ways/tools for global governance – to identify and decide on issues.

Tackle the issue of ‘responsibility to…’ whilst respecting sovereignty. When a sovereign state fails to fulfil a responsibility to its people, then what is the role of the international community and what are the tools with which to fulfil that role? Political not technical tools.

 

That is what is restraining action at a national level.

But at the same time, need to address domestic politics – reframe the domestic discourses. Help each other to get our publics to understand the issues and to transcend their own narrow interests.

I don’t have the answers, but at the moment we don’t even seem to be asking the right question. Focussing on the technical elements of water resource management or carbon reductions is not sufficient. Green growth as a concept is a step in the right direction, but still predicated on the us versus the world mentality. That’s what needs to change.

This is all I can come up with keep my sanity.Â [Duran Duran â&#128;&#147; Rio](http://open.spotify.com/track/43eBgYRTmu5BJnCJDBU5Hb)