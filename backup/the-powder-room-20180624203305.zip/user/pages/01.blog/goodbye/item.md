---
# http://learn.getgrav.org/content/headers
title: Goodbye
slug: goodbye
# menu: Goodbye
date: 18-06-2006
published: true
publish_date: 18-06-2006
# unpublish_date: 18-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**18th June 2006, 1605**  
*A packed 747-400 on a Heathrow runway, sandwiched between two middle-aged Americans bordering on elderly*

It’s begun and it feels strangely surreal. I’ve just said bye to Jen for 3 months – one of the hardest things I’ve had to do, but I fear that worse is yet to come as I miss her more and more each passing second

I guess it’ll be fairly ok for the first few weeks as we spend that sort of time apart in the UK anyway, but then it’ll probably kick in.

She’s been lovely for the past few days, putting up with me getting all stressy about silly things. She’s done lots of lovely things for me, a touching scrap book, some inspirational cards and a load of music to remind me of her. I’m so happy, but also feel like the worst boyfriend in the world, having totally failed to do anything for her due to incompetence and lack of organisation – sorry Jen.

Still, must be positive, will see her soon enough and then we’ll start out adventure together!