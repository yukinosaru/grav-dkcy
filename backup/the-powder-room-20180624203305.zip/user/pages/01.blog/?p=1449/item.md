---
# http://learn.getgrav.org/content/headers
title: Climate denialism
slug: 
# menu: Climate denialism
date: 20-01-2017
published: false
publish_date: 20-01-2017
# unpublish_date: 20-01-2017
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Oxford English Dictionary  
 denial NOUN  
 1.3 Refusal to acknowledge an unacceptable truth or emotion or to admit it into consciousness, used as a defence mechanism:

Focus is on Paris – a great achievement.  
 But no enforcement of pledges.  
 Even if pledges are met, we still end up with x degrees

First time the world has committed to 2 degrees – but that still gives us 33% chance of dangerous climate change.

Pointing to extreme weather phenomena and saying this is evidence is also denial. Reality is that it’s more complex, but that the probability of these sorts of events is likely to increase.

Activists point the finger at dirty industry or big business – when we are a part of it. Mobile phones, laptops, driving, eating global food, using the internet.

Need to acknowledge an unacceptable truth – we are not going to stop climate change, there’s no point wasting energy on assigning blame – we need to understand what’s likely to happen and plan for it. It’s not an inevitability, we don’t have to give up efforts on things like renewables – but let’s not kid ourselves that we’ll achieve what we need to in time. This is a damage limitation situation.

Understand how steady temperature rises will affect global supply chains and specific products. The risks that extreme events will have for the food system etc.

SCIM – 6 ways to die.  
 too hot (see cooling and shelter)  
 too cold (see heating and shelter)  
 thirst (see water supply and water purification)  
 hunger (see food, agriculture, organic and sustainable farming, and permaculture)  
 illness (see public health and medical devices)  
 injury (see medical treatment – planned for late 2011/early 2012)