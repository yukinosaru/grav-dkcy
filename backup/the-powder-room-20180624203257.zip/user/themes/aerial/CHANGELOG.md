# v2.0.4
## 08/05/2016

1. [](#bugfix)
    * Fixed demo link ([#723](https://github.com/getgrav/grav-plugin-admin/issues/723))

# v2.0.3
## 03/06/2015

1. [](#improved)
    * Update jquery with named asset.
    * Update theme for working with Grav 0.9.19.

# v2.0.2
## 01/13/2015

1. [](#bugfix)
  * Update README.
  * Update title for error page title.

1. [](#new)
  * Add Error template.

# v2.0.1
## 01/09/2015

1. [](#bugfix)
  * Small fix.

1. [](#improved)
  * Update [README](README.md).

# v2.0.0
## 01/07/2015

1. [](#new)
  * Add random background. Use the media page images to load the backgrounds.
  * Start conversion to Grav Theme.
