---
# http://learn.getgrav.org/content/headers
title: If
slug: if
# menu: If
date: 21-09-2006
published: true
publish_date: 21-09-2006
# unpublish_date: 21-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**21 September 2006, 23.37**  
*In bed, eating lollies (sweets to non-Kiwis – no idea why they call them lollies, there’s no stick or frozen syrup involved, but I digress…)*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/meandsunriseovertc.jpg "Me at sunrise over TC")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/meandsunriseovertc.jpg)Why I’m up when I should be fast asleep for tomorrow, I don’t know! Anyway, had a good day today – fresh powder, lots of strong riding and positive feedback. I scored well on the areas that we’re being assessed on, but still have work to do. I’m a little disappointed, cos I was hoping to have had it all wrapped up by now so that tomorrow wouldn’t be so pressured. But now, I’ve got one last shot to prove myself – I know I can do it, I just need to get out there, focus and do the business.

You’ve probably noticed that I like to quote various bods, tonight, Kipling is my inspiration for tomorrow:

* *

 
    <em>If you can keep your head when all about you
    Are losing theirs and blaming it on you,
    If you can trust yourself when all men doubt you
    But make allowance for their doubting too,
    If you can wait and not be tired by waiting,
    Or being lied about, don't deal in lies,
    Or being hated, don't give way to hating,
    And yet don't look too good, nor talk too wise:
    
    If you can dream--and not make dreams your master,
    If you can think--and not make thoughts your aim;
    If you can meet with Triumph and Disaster
    And treat those two impostors just the same;
    If you can bear to hear the truth you've spoken
    Twisted by knaves to make a trap for fools,
    Or watch the things you gave your life to, broken,
    And stoop and build 'em up with worn-out tools:
    
    If you can make one heap of all your winnings
    And risk it all on one turn of pitch-and-toss,
    And lose, and start again at your beginnings
    And never breath a word about your loss;
    If you can force your heart and nerve and sinew
    To serve your turn long after they are gone,
    And so hold on when there is nothing in you
    Except the Will which says to them: "Hold on!"
    
    If you can talk with crowds and keep your virtue,
    Or walk with kings--nor lose the common touch,
    If neither foes nor loving friends can hurt you;
    If all men count with you, but none too much,
    If you can fill the unforgiving minute
    With sixty seconds' worth of distance run,
    Yours is the Earth and everything that's in it,
    And--which is more--you'll be a Man, my son!</em>

**