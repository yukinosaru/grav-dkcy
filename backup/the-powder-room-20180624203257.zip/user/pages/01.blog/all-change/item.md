---
# http://learn.getgrav.org/content/headers
title: All change
slug: all-change
# menu: All change
date: 02-10-2006
published: true
publish_date: 02-10-2006
# unpublish_date: 02-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**2nd October 206, 19.51**  
*Bits and Bytes*

Well, it’s all change here, we’ve moved out of Alpine Resort and back into the Mountain View Backpackers, but most importantly of all, Jen’s arrived! Finally, we’re back together again, I didn’t quite believe it would happen, but she’s here and we’re loving it!

We’ve got a lovely little room in the Mountain View and we’ve made it all cosy. Really quite enjoying being back there, it feels like home. Been up at Cardrona for the past 2 days, teaching Jen to snowboard – I think it went OK, she did really well and managed to link turns after only 1 day (personally, I put it down to the high quality instruction she’s been getting ;p), plus she’s still talking to me, which is a result!

It’s been quite sad too cos everyone’s been leaving over the past few days. Pete and Claire disappeared off on Saturday and Ryan left today, so it’s been quite mixed. Still, it doesn’t feel like a goodbye, cos I’ll see them all in Colorado!

On other news, Doris failed her Warrant of Fitness (equivalent to an MOT) – her suspension and brakes need work, it’ll cost about NZ$500 to fix, quite a lot and a bit of a pinch, but in the grand scheme of things it hasn’t cost that much to have her and it’ll make it easier to sell her.