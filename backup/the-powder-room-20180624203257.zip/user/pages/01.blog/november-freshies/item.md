---
# http://learn.getgrav.org/content/headers
title: November Freshies
slug: november-freshies
# menu: November Freshies
date: 17-11-2016
published: true
publish_date: 17-11-2016
# unpublish_date: 17-11-2016
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin

---

The snow has come early this year and after an intense 2 day storm, the skies cleared and the sun came out. Blue sky on sugary white snow, the perfect colour combination.

With a group of friends, I headed up to Avoriaz, parked at the top of the Prodains gondola, strapped on my snowshoes and headed up the Arare piste.

![](http://www.dkcy.com/images/freshies.jpg)

 ## Remembering why snowshoes suck

- - - - - -

After about 10 minutes, I realised that I was the only one in the group on snowshoes, carrying my snowboard. The others either had splitboards or were on touring skis. As I slowly dropped back, puffing and wheezing, I realised the value of a splitboard. Every step was an energy-sapping chore, but I kept plodding on slowly, stopping occasionally to enjoy the view and catch my breath.

![](http://www.dkcy.com/images/banner.png)

 ## Payoff!

- - - - - -

After about 90 minutes of climbing, we reached the top of the Arare teleski, which would have normally taken just a few minutes. Pausing for some lunch, we soaked in the views and rested our legs

Then, ditching the torture instruments that are my snowshoes, I put my board on and remember what it was all about. Sparkly, soft powder slipping away under the board. Fresh slashes into untouched pockets. Whooping and hollering like idiots, we made our way down.