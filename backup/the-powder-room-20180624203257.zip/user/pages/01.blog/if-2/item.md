---
# http://learn.getgrav.org/content/headers
title: If&#8230;
slug: if-2
# menu: If&#8230;
date: 22-09-2006
published: true
publish_date: 22-09-2006
# unpublish_date: 22-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**22nd September 2006, 13.29**  
*Internet kiosk at TC*

Well, Kipling provided the script for today, but in a somewhat different manner than what I was expecting.

*“If you can meet with Triumph and Disaster  
 And treat those two imposters just the same”*

Yep, failed my BASI exam. Was on my riding, I just wasn’t up to scratch. It’s the right decision, but it’s still tough and I’m gutted. But at least I’ve got my Stage 1 and a job to go to.

I’m still proud of what I’ve achieved and how far my riding has come this season – this was always going to be a huge challenge and to have walked away with 2 qualifications and a job means a lot to me. I’ve travelled the road not taken and don’t regret a second of it.