---
# http://learn.getgrav.org/content/headers
title: Poma runs!
slug: poma-runs
# menu: Poma runs!
date: 16-07-2006
published: true
publish_date: 16-07-2006
# unpublish_date: 16-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**16th July 2006, 21.00pm**  
*Alpine Resort after a top day riding*

Just eaten steak and chips kindly cooked for me by Pete – yum!! Went up to TC today and had an awesome day – rode the Saddle Basin for a bit, playing with the powder, then came down to the poma lifts and practiced teaching for the CSI exam.

Met a girl Jes, who was teaching herself to snowboard, so I offered to take her through the teaching progressions and spent most of the morning teaching her to turn. By the end she was turning pretty well and I left her heading up to the big green run down. Her boyfriend was impressed and both were really grateful, so I was quite chuffed with myself!

Pete and I spent the afternoon talking through and practicing all our demonstrations. Went really well and feel like I’ve got a handle on how to explain stuff. Then we had a good blast down Main Street (one of the blue runs) and I feel like my turns are really taking shape now – so all in all, pretty stoked, in buoyant mood for tomorrow!