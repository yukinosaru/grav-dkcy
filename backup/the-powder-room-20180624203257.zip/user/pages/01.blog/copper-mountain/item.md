---
# http://learn.getgrav.org/content/headers
title: Copper Mountain
slug: copper-mountain
# menu: Copper Mountain
date: 07-03-2007
published: true
publish_date: 07-03-2007
# unpublish_date: 07-03-2007
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [copper mountain,snow,travel,copper mountain,snow,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**Wednesday 7th March**  
*At home*

Having talked about it all season, Jen and I finally got round to visiting another resort. Given that it’s part of Intrawest and we can ride for free, we decided to head to [Copper Mountain](http://www.coppercolorado.com/). The sun was shining, snow was great and Jen was riding really well. Had a fab time, exploring new terrain – planning on hitting Loveland next week!