---
# http://learn.getgrav.org/content/headers
title: Te Anau
slug: te-anau
# menu: Te Anau
date: 11-10-2006
published: true
publish_date: 11-10-2006
# unpublish_date: 11-10-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**Sunday 8th-10th**  
*Te Anau and almost Doubtful Sound*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/teanaupiershot.jpg "Pier at Te Anau")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/teanaupiershot.jpg)Unfortunately, our night was a bit spoiled by noisy neighbours blasting out bassy tunes until 4am! Doh! Morning greeted us with a calm sunrise, followed by gale force winds. Not really wanting to hang around too long, we packed up and headed out to Te Anau, about 2 1/2 hours drive south and west of Queenstown.

Great drive down, with beautiful views, but the winds made driving a little tough and it took a bit longer than expected!

After a bit of hunting around, we camped up at the Top 10 Mountain View holiday park. Nice little spot with good facilities and close to the centre.

The weather continued to worsen into the next day, with heavy rain and winds. Undeterred, we booked up 2 day sea kayak trip round Doubtful Sound with [Fiordland Wilderness Experiences](http://www.fiordlandseakayak.co.nz/ "Link to FWE website"), run by Daphne and Bill, a lovely couple who really seem to have found their calling.

Quite excited and a little daunted by the thought, we bought some supplies ready for the adventure. Jen was understandably a little worried about the thought of it all, particularly having cold wet feet for 2 days!

Unfortunately, the next day, the weather continued to worsen and the trip was called off. But determined to make the best of a bad situation, Jen and I fuelled up Doris and trekked off to Milford Sound.