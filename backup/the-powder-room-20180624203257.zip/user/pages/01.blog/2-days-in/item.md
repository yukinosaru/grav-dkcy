---
# http://learn.getgrav.org/content/headers
title: 2 days in&#8230;
slug: 2-days-in
# menu: 2 days in&#8230;
date: 24-08-2006
published: true
publish_date: 24-08-2006
# unpublish_date: 24-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**24th August 2006, 22.00**  
*At the table, fretting about tomorrow*

So 2 days into the Stage 1 exam – seems to have gone OK so far, day 1 was a bit sketchy for me, I was really stiff in my riding, but today seemed to be better. Definitely a different feel to the CSI exam, much more focussed and I feel that I’m being watched on every run. Had our movement analysis session tonight, which went well but was slightly frustrating as we have to learn to present in a slightly different way from what we’ve been used to.

That’s part of a bigger challenge – we’ve got Greg as our examiner and as always we need to work with his particular style, so have to adapt our explanations and approaches so that they match what he’s looking for. I guess it’s good to be flexible, but it’s difficult to change your style! But still, Greg’s a good guy, quite relaxed in general, but has a tendency to want a specific answer in his mind sometimes, which can make things a little trickier.

Anyways, tomorrow is the Level 4 progression and more rider improvement – lots of switch apparently, which is a cause for concern for me – it’s definitely a weaker element of my riding. I know I can do it, but just need to get my head straight!