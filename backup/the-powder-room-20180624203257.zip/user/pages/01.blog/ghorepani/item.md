---
# http://learn.getgrav.org/content/headers
title: Ghorepani
slug: ghorepani
# menu: Ghorepani
date: 05-11-2008
published: true
publish_date: 05-11-2008
# unpublish_date: 05-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Tada! Annapurna](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081105_4396-200x300.jpg "Annapurna")Tada! Annapurna



![Michelle's boot!](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081105_4439-200x300.jpg "Michelle's boot")M's boot!



Unsure if we’ll make it, we set off early. Long and tough climbing first up – 3280 (allegedly) stone steps. Pauses for tea and water, but exciting glimpses of Annapurna through trees. It eases off, but not much – a long climb to Ghorepani and noticeably colder temps – we’re now around 3000m. We stagger through to Deorali and find the Mountain View guesthouse and a room with a view, hot water and a comfortable bed. Wrapping up warm, we scout the place out, finding Noel, Jess and Dave. Nice buzz to the place a surprisingly well stocked.

![Nepali kids - sooo cute!](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081105_4435-300x200.jpg "Nepali kids")Nepali kids - sooo cute!



![Mmm, dim sum.](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/20081105_4453-300x200.jpg "Chicken feet")Mmm, dim sum.