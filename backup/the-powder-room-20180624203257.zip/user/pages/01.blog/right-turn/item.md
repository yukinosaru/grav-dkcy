---
# http://learn.getgrav.org/content/headers
title: Right turn
slug: right-turn
# menu: Right turn
date: 23-02-2011
published: true
publish_date: 23-02-2011
# unpublish_date: 23-02-2011
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [For Tea Too,The Rat Race]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![](http://user47216.vs.easily.co.uk/wp-content/uploads/2011/02/1242903761-e1298740584382-200x200.jpg "Brixton tube")Brixton reflection



*Brixton underground station, London.*  
 This is the wonderful part of South London that I am proud to call home. It’s the morning rush hour and a torrent of humanity pours through the mass of morning activity – market traders setting up for the day, incense sellers outside Iceland and fluorescent jacketed newspaper distributors. It snakes along Brixton High Street, flowing into the great yawning mouth of the station.

Nestled at the end of the Victoria underground line, Brixton enjoys the luxury of always having at least one train waiting at the bottom of the grubby escalator that looks permanently in a state of repair. People rush through, grabbing a ubiquitous free paper, shaking off leaflet touts and queuing like sheep to beep their Oyster cards against the yellow pad, awaiting their judgement. Occasionally some poor soul drops their pass or has run out of credit causing an almost irrevocable blockage. Smartly suited men and power dressing women mutter angrily or tut loudly – such is their thirst to get to work. The whole scene is offset by the tranquil overtones of Bach or Vivaldi, soothing frayed tempers and zombie sheep.

After the commuter equivalent of a waterfall, the survivors scurry down the escalator pausing only to examine both trains and decide which is leaving first. Looks like left wins today. Reaching the bottom, I turn right.