---
# http://learn.getgrav.org/content/headers
title: More CO Powder
slug: more-co-powder
# menu: More CO Powder
date: 27-02-2007
published: true
publish_date: 27-02-2007
# unpublish_date: 27-02-2007
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [snow,winter park,snow,winter park]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**26th February 2007, 23.34**  
*Living room, Meadowridge*

So another typical snow storm in Fraser, just 6 inches or so. Had an immense day riding trees and bumps, before catching up with Jen and cruising around together for a bit.

Just thought we’d try a bit of movie on the site!  
[Fraser Snow](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/frasersnow.mov)