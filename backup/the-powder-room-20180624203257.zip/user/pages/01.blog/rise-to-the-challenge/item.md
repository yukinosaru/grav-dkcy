---
# http://learn.getgrav.org/content/headers
title: &#8216;Rise to the Challenge&#8217;
slug: rise-to-the-challenge
# menu: &#8216;Rise to the Challenge&#8217;
date: 04-08-2006
published: true
publish_date: 04-08-2006
# unpublish_date: 04-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**4th August 2006, 18:00**  
*Alpine Resort*

Had a good-ish sort of day today – the trainers had a chat with us about our progress so far – they reckon that I’m not good enough to pass Stage 1 just yet, but if I improve at the rate I have been then I might be alright for the exam. Basically, it’s going to be really tough few weeks and I’ve got to put a lot of work in if I’m to pass – they said that I shouldn’t be surprised if I don’t pass.

As for the BASI exam, I’m even further away! It was better than I expected, but I know it’s going to be a big challenge. Just need to knuckle down and get on with it really!

On the plus side, I’m going heliboarding tomorrow. Just got back from stretch class – really good, feel much more relaxed now. Heading off to watch a DVD and chill out round at Ros’ place. The others have gone to the Burton Open to watch all the pro snowboarders, but I decided I could do with the stretch and a gentle night!