---
# http://learn.getgrav.org/content/headers
title: The Mousetrap
slug: the-mousetrap
# menu: The Mousetrap
date: 20-11-2006
published: true
publish_date: 20-11-2006
# unpublish_date: 20-11-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**21st November 2006, 11.32am**  
*The Mousetrap Hostel, Paihia*

It’s been a while since the last update, but we had a lovely few days in Raglan, staying with Nicky (and an enormously fat but lovable cat). We ended up staying longer than planned, but it was just what we needed – time to stop and relax and enjoy life. Nicky was housesitting at a lovely place overlooking Whale Bay – apparently a top surfing spot.

Recharged, we headed south to Waitomo to visit the famous glowworm caves. On Ronnie’s recommendation (ta Ronster!) we went with a small company called [Rap, Raft n Rock](http://www.caveraft.com/ "Link to Rap, Raft and Rock"). Simon, the owner, was our guide and we rappelled into the cave (about 27m!), then went blackwater rafting (on a rubber tubes) through all the glowworms before rock climbing our way out.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2123.jpg "Bay of Islands")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683653_img_2123.jpg)So now, we’ve headed north again and after a brief stop in Auckland, have landed in the Bay of Islands. Had a beautiful sailing trip around with [Mike and the Gungha II](http://www.bayofislandssailing.co.nz/ "Link to Gungha website") (the boat that Peter Blake circumnavigated the globe with!) and now we’re waiting for the US Government to decide whether or not we’re terrorists, which could be anytime between now and December.

Unfortunately that means that our trip to Fiji isn’t happening anymore, which is a bit of bummer. But, mustn’t grumble – we’re at [The Moustrap](http://www.mousetrap.co.nz/ "Link to the Mousetrap website") (how ironic), a lovely hostel run by Jake and Nikki and seemingly overrun with Germans! It’s a really homely place (must get some photos up) as is evident by the amount of long-stayers here. Paihia is the main town in the Bay of Islands and is very tranquil, with beautiful scenery all around. And here we’ll wait.