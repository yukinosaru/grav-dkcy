---
# http://learn.getgrav.org/content/headers
title: Township
slug: 
# menu: Township
date: 11-09-2008
published: false
publish_date: 11-09-2008
# unpublish_date: 11-09-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Township tour  
 Brian District 6  
 First ever heart transplant.  
 Second ever with District 6  
 Golden the tin man  
 Vicky’s B&B  
 Beauty’s teaching and HIV  
 Kindergarten – excitable happy kid, fascinated by green water bottle.  
 Women doing all the work.  
 Guilt/uneasiness/hypocrisy  
 Sadness  
 Happiness  
 Trying to process information