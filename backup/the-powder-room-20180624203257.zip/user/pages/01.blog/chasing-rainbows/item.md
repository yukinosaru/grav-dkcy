---
# http://learn.getgrav.org/content/headers
title: Chasing Rainbows
slug: chasing-rainbows
# menu: Chasing Rainbows
date: 29-10-2008
published: true
publish_date: 29-10-2008
# unpublish_date: 29-10-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: [lebenskrankheit,travel,lebenskrankheit,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**Wednesday 29 October 2008, 23.39**  
*Lying across my bed*

![Rainbow over Sharm el Sheikh](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/rainbow-on-mountain-portrait-197x300.jpg "Rainbow over Sharm el Sheikh")The last rainbow I chased



Here we are again, on the eve of another adventure. I feel I should mark the occassion with a momentous entry, but I don’t feel ready to blog yet. I’ve been on another crazy ride these last few months and now find myself about to step out again – admittedly only for 5 weeks, but it’s another journey. Another quest to find something, myself, space, peace, resolve? Perspective?

I’m struggling with the words to express myself at the moment, but I’m reminded of PG Wodehouse:  
 “He felt like a man who, chasing rainbows, has had one of them suddenly turn and bite him in the leg”