---
# http://learn.getgrav.org/content/headers
title: Reflection at a time of change
slug: 652
# menu: Reflection at a time of change
date: 04-01-2009
published: false
publish_date: 04-01-2009
# unpublish_date: 04-01-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Once upon a time there was a boy, a dreamer. Passionate, driven, energetic. Who loved life and wanted all the best. Who saw the positive in everything and stayed centred in the face of adversity. Who pursued his goals with unwavering faith and dedication.

But something happened and he now feels beaten down by life. Lost, directionless, apathetic. What happened along the way? How did that change? He is inspired by his old self and longs for a return to that feeling. But also feels like it’s wrong to go back. He’s changed, he’s made life decisions. But he’s also lost perspective and needs to look at all of this in the grand scheme of his short adult life so far.

Through his life he’s influenced and inspired people along the way. He’s touched hearts and ignited dreams. He’s also taken that away and doesn’t really know the impact of that. He sees patterns repeating themselves and worries about the present. Perhaps he needs to make peace with himself before he can truly find peace without.