---
# http://learn.getgrav.org/content/headers
title: Ja-pow
slug: ja-pow
# menu: Ja-pow
date: 15-01-2009
published: true
publish_date: 15-01-2009
# unpublish_date: 15-01-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [instructing,powder,snow,instructing,powder,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Unitas dining hall, large can of Asahi in hand  
 It snowed today. A lot. All day. Man, I had to shovel my way out of the room this morning. Got to work early cos I was on set-up duty and spent the morning shovelling snow off the magic carpet, then Tom gave me an all-day private level 3 (translation: 7 hours of work, guests that can actually snowboard, generally a free lunch too). Hung around for half an hour waiting for them, freezing my knackers off, but then had a great day, trundling around, teaching them to ride powder and generally exploring. The snow in the trees was sooooooo deep, it was hip deep at least and face shots (when you spray yourself with snow) all round.  
 Although to be honest, it was bloody hard work and I was complaining about it earlier, but if I think about it, I’m still getting paid to ride and chat to people. I’m physically shattered today, but a bad day on the slopes is still better than a good day in the office!