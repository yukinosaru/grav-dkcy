---
# http://learn.getgrav.org/content/headers
title: Lumbini Video Coach
slug: lumbini-video-coach
# menu: Lumbini Video Coach
date: 09-11-2008
published: true
publish_date: 09-11-2008
# unpublish_date: 09-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![Machapuchare in the morning](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/11/20081109_4596-200x133.jpg "Machapuchare in the morning")Machapuchare in the morning



Early start, Mustang bus station, conned into sitting at a nice cafe by a guy whose daughter is a Gurkha. Masala chiya and random pastry in the morning sun. Indian video coach showing Hindi films.

More random roadside curry – mixed with rice, potato, onion, some sort of round yellow bean (chickpea? mung?), chilli powder, coconut powder and possibly lemon, all served in a newspaper cone with a piece of card as a scoop. Yum! First time I had it was on the way back from Beni – 5 rupees and your life in your hands. A wiry Indian-looking guy with a tray balanced on a cushion on his head and a stand weaving in and out of buses, setting up before whizzing everything up in a dirty plastic beaker!

EDIT: I’ve since discovered that it’s called chat and is a mix of soya beans, radish, chilli, salt and lemon

![Our chariot](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/11/20081109_4599-133x200.jpg "Lumbini bus")Our chariot



Dodgy roadside stops, meet Prince and friends – helps me buy some yummy clementines – 30 rupees for a big bag. He gives me his card and invites me to look him up in India.

Our trip comes to an abrupt halt as we are almost ejected at the edge of Bhairawa, which turns out to make life easier getting to Lumbini – decision made then!

Staggering through the dust and noise we somehow find a bus just leaving for Lumbini and jump on the roof – M loses a shoe and a Nepali-style rescue mission sees a random guy on a bike throw it up, just as we move off.

Dusty roads lined with mango trees – terrifyingly narrow, but refreshing in the heat. Feels much more Indian – the people, the heat, the food. 60 rupees gets the 2 of us to Lumbini. We hop off onto a dusty crossroads and stagger into Lumbini Bazaar and the Lumbini Village Lodge. Too tired to decide otherwise, we go for it. 2 cold showers later, we feel almost human and wander out for food. It’s a pleasant and quiet village and feels very homely. The 3 Foxes restaurant entices us in and lots of food emerges, including banana custard! Fearsome number of mozzies even though I’m coated in Deet. Pleasantly full and satisfied with our day, we drift off to sleep under the safety of my mozzie net.