---
# http://learn.getgrav.org/content/headers
title: Freestyleee
slug: freestyleee
# menu: Freestyleee
date: 27-07-2006
published: true
publish_date: 27-07-2006
# unpublish_date: 27-07-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**27th July 2006, 21.25**  
*On my bed having just come back from Swiss Ball class*

Fun day today – we had a new trainer, Dan (great name!) and I’m in a group with Claire, Kristine and Ryan. Spent the afternoon trying out freestyle stuff – nose rolls, 180 ollies and buttering. Dan’s a really great freestyle coach and took us through a gradual progression that had us all buttering by the end of the afternoon – result!

On the downside, I’m coming down with something – just a cold type thing, but feeling all feverish and have a sore throat. Irritating more than anything – I’m fed up of feeling tired/injured/sick!

Anyways, could be worse, lots of people up at Cardrona are coming down with a nasty gastroenteritis thing – a few of our skiiers have got it now cos they’re doing their CSI there. Hoping to avoid that one!!