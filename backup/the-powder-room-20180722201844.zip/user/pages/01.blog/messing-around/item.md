---
# http://learn.getgrav.org/content/headers
title: Messing around
slug: messing-around
# menu: Messing around
date: 25-05-2009
published: true
publish_date: 25-05-2009
# unpublish_date: 25-05-2009
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,photography,japan,photography]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

[Pierre Wikberg](http://pierrewikberg.blogspot.com/ "Pierre Wikberg's Blog") is one of my favourite director/photographers – I love the creativity and the fun he injects, so here’s the first of a few experiments inspired by some of his work.

[![Shinsennuma](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/05/shizenobu-20090521_tsukasa4.jpg "Tsukasa x 4")](http://user47216.vs.easily.co.uk/wp-content/uploads/2009/05/shizenobu-20090521_tsukasa4.jpg)Shinsennuma