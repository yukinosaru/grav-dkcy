---
# http://learn.getgrav.org/content/headers
title: It&#8217;s all happening
slug: its-all-happening
# menu: It&#8217;s all happening
date: 21-02-2007
published: true
publish_date: 21-02-2007
# unpublish_date: 21-02-2007
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [lebenskrankheit,snow,winter park,lebenskrankheit,snow,winter park]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**20th February, 17.53**  
*In the kitchen*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_20421-199x300.jpg "Koru")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_20421.jpg)Wow, what an epic day! So we had about an inch of fresh snow (not much, but enough!), Pete’s out here visiting and the sun is shining. Yesterday we went skiing in the afternoon and then today went riding all over the shop – trees, bumps, steeps and a bit of freestyle! I was having a storm today, riding really well through the trees and generally enjoying things.

So, thoughts have started to turn to what happens after the season, I’d really love to do another season, but although I love instructing, I struggle with the politics and hassle that comes with it, plus this life is not really sustainable in the long term, so I thought I’d explore my options for coming back to London. I registered my CV with a recruitment consultancy and by some remarkable stroke of fortune, the next day I had Entec Consulting (a top environmental consultancy) call me.

After what turned out to be two phone interviews with one of the Directors, they offered me a job as a senior consultant in their climate change team, with the aim of taking over the principal consultant role in 6 months. It’s a pretty good package and a fantastic opportunity as they are looking for someone to develop their climate change business. Even though I’ve got no consultancy experience, they’re really keen on me and want to put me through my paces in the first few months, with some fast track training and development. I’ve been thinking about it over the weekend and decided to take it, so I’ll be starting on the 1st May. The snowboard instructor option will be here for me if I decide that’s the route I’d like to take, but at the moment I think a return to London and working in a professional environment on an issue I really care about is the right choice. I have to make sure that I don’t fall back into the same unhappy lifestyle I was leading in my last job, but so far it seems a much more balanced existence. Plus it’ll pay for some long snow holidays!