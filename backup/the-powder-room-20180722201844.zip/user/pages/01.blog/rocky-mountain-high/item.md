---
# http://learn.getgrav.org/content/headers
title: Rocky Mountain High
slug: rocky-mountain-high
# menu: Rocky Mountain High
date: 18-12-2006
published: true
publish_date: 18-12-2006
# unpublish_date: 18-12-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rocky Mountain High]
    tag: [snow,winter park,snow,winter park]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**17th December 2006, 20:24**  
*The McKellar’s*

Well, it’s been a crazy few days! Having made contact with my supervisor at Winter Park, it turns out that I was just in time for the new hire academy that I needed to do before starting work. However, I had no way of getting up to WP in time and was distinctly carless. Gordon very kindly came to my rescue by driving me up there!

So we’ve moved into our condo now, it’s really nice (although there was a flood over the summer so our carpets still need some work) – we’ll be living with two others, Colin and Tiktak. It’s all a bit hectic at the moment with work, trying to set up life in the mountains and getting used to the altitude! Up here in Fraser, we’re at around 9,000 feet so the air is a lot thinner, plus it makes the air drier so we’re drinking gallons of water to try to stay hydrated. Up at the resort, the mountains go up to around 12,000 feet, so altitude sickness is a genuine risk. But we’re taking it easy and trying not to over-exert ourselves.

We’ve got no internet access at the moment and Fraser/Winter Park is somewhat lacking in internet cafes that open late enough for us to use, so we’re a little cut off, but hopefully that should be sorted soon enough.