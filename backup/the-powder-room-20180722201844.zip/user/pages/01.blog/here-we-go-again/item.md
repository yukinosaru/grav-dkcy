---
# http://learn.getgrav.org/content/headers
title: Here we go again
slug: here-we-go-again
# menu: Here we go again
date: 29-08-2006
published: true
publish_date: 29-08-2006
# unpublish_date: 29-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**29th August 2006, 22.02**  
*On me sofa, trying to fix Claire’s computer*

Day 1 of the BASI training and I had possibly my best day riding ever. Things just flowed today and I was riding like I should be. Was a real confidence boost and I thoroughly enjoyed myself today. I reckon it’s cos the pressure’s been lifted and I can relax a bit more now.

We had an evening lecture setting out what was required and going through some theory. Basically, BASI score things from 1 to 6 and we need to be scoring 5 on most things, which is the ‘early acquired’ phase – which means that we are doing it without thinking about it. I’m feeling pretty buoyant about this and we’ve got 2 weeks of training to get to that level, so I hope I can do it. Again, I’m pretty confident about my technical knowledge and my teaching, just not so sure about my riding. Well, we’ll see how things go!

I’ve also decided to demo a few more boards, trying a Rome Agent 158 tomorrow – it’s a bit more freestyle and has loads more pop than my old board, so will be chucking me about the mountain!