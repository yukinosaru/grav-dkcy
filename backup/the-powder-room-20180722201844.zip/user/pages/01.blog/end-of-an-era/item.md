---
# http://learn.getgrav.org/content/headers
title: End of an era
slug: end-of-an-era
# menu: End of an era
date: 08-09-2006
published: true
publish_date: 08-09-2006
# unpublish_date: 08-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**8th September 2006, 16.58**  
*On my bed, after an epic day*

Today was our last day of training – it kinda crept up on me, but there we have it, all we’ve got left is the BASI exam. It’s been a challenging experience, I have in equal parts hated, admired, reviled and loved the trainers, but what is undisputable is how far I feel that I’ve come. In terms of my riding, my resilience and my understanding of myself and others.

Coming here was a real step for me and looking back, I’d forgotten quite how much this means to me. Somewhere amongst the changes, the stress of exams, self imposed pressure to improve my riding and wanting to be seen in a good light, I’d lost perspective. But in the last week or so, I feel like I’ve remembered what I came here for and how life is. I’ve remembered that life is fun!

> **
> 
> What is this life if, full of care,  
>  We have no time to stand and stare.
> 
> No time to stand beneath the boughs  
>  And stare as long as sheep or cows.
> 
> No time to see, when woods we pass,  
>  Where squirrels hide their nuts in grass.
> 
> No time to see, in broad daylight,  
>  Streams full of stars, like skies at night.
> 
> No time to turn at Beauty’s glance,  
>  And watch her feet, how they can dance.
> 
> No time to wait till her mouth can  
>  Enrich that smile her eyes began.
> 
> A poor life this if, full of care,  
>  We have no time to stand and stare.