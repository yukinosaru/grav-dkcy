---
# http://learn.getgrav.org/content/headers
title: First day at TC!
slug: first-day-at-tc
# menu: First day at TC!
date: 28-06-2006
published: true
publish_date: 28-06-2006
# unpublish_date: 28-06-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [snow,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**28th June 2006, 1800**  
*Back at Wanaka after day one at TC*

Wow! Had my first day riding Treble Cone – really great mountain, but pretty tough. I struggled a little today and my confidence is rock bottom at the moment. Looking forward to the course starting for real.

I feel like I should be ranting and raving about how amazing TC was and my first day of the season, but actually, I had a pretty pants day yesterday.

TC’s pretty tough, there’s a couple of groomed cruising green trails, but the rest of the mountain is pretty much off-piste powder. That’s awesome – if you can ride powder. Which I can’t with any tremendous confidence and when it’s starting to get cut up and bumpy, I really struggle. I took a tumble and hurt my wrist a bit too, which didn’t help – then I got stuck in some deep powder and had a bit of a paddy as a result!

Didn’t help that the others are much better than me, so makes me worry a little and feel small. But hey, I’m here to learn and learn I will on this mountain!

Just looking forward to learning to ride this mountain properly and getting some instruction from the Rookie Academy crew (who all seem like top guys and gals).