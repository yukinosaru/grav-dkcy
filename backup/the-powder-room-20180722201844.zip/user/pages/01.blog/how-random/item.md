---
# http://learn.getgrav.org/content/headers
title: How random?
slug: how-random
# menu: How random?
date: 19-12-2008
published: true
publish_date: 19-12-2008
# unpublish_date: 19-12-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [凄いですね (sugoi desu ne)]
    tag: [japan,synchronicity,japan,synchronicity]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

So, went to the opticians today and happened to catch sight of the Metro – what did they have on their front page? A little snippet about Japan. So I turn to the [2 page feature,](http://www.metro.co.uk/travel/article.html?Slope_off_for_snowboarding_in_Japan&in_article_id=453094&in_page_id=5) which is all about Niseko! Having never seen anything about Niseko, Hokkaido or even Japan, suddenly it’s sneaking out. Clearly there are higher powers speaking to me. Even if that happens to be Rupert Murdoch.