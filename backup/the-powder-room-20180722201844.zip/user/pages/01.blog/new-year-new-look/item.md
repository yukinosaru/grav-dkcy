---
# http://learn.getgrav.org/content/headers
title: New year, new look
slug: new-year-new-look
# menu: New year, new look
date: 22-01-2014
published: true
publish_date: 22-01-2014
# unpublish_date: 22-01-2014
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

![](https://media.licdn.com/mpr/mpr/AAEAAQAAAAAAAAasAAAAJDcwMTUwMDAwLTQ3YTMtNDUwNi04NzU5LTVlNGM0NTlhYWFhNQ.jpg)

  In case you haven’t noticed, I decided that it was time to refresh the look of the site. I designed the previous version 5 years ago and web design has come a long way since then.  
 The logic was to create a cleaner, flatter and more content-focussed look, with more relevant content showing up at the bottom of each post (other posts from the same category now follow each post). Still have some work to do on it, but this is good enough to start with – imperfect something is better than a perfect nothing ð&#159;&#153;&#130;  