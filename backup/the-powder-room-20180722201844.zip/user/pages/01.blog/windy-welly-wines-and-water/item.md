---
# http://learn.getgrav.org/content/headers
title: Windy Welly, Wines and Water
slug: windy-welly-wines-and-water
# menu: Windy Welly, Wines and Water
date: 04-11-2006
published: true
publish_date: 04-11-2006
# unpublish_date: 04-11-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [NZ Road Trippin']
    tag: [new zealand,travel,new zealand,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**5th November 2006, 00.50am**  
*Kitchen of De Bretts Holiday Park, Taupo*

Don’t ask why I’m in the kitchen at well past midnight, I just am! Anyways, we’ve been in North Island for a few days now and have had some mixed experiences.

The Interisland ferry was nice, the crossing was real calm and the ferry was well equipped, even if we nearly ended up getting trapped on board – as we came into Wellington, the car in front of us still had no driver! But a bit of crafty maneouvering and we were away.

We didn’t get on with Wellington – aside from staying in a manky hostel that had pubic hair in the bed (!), it was just big, dirty and noisy. I guess if we’d stayed for longer we’d have gotten to appreciate it more, but we wanted to head off as soon as possible and get out to the country.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164685303_img_2300.jpg "Me talking to ducks")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164685303_img_2300.jpg)Next up was Hawke’s Bay originally to see Nicky, but she’s staying in Raglan for a bit longer, so instead we stayed at her uncle Tim’s farm near Waipawa. It was absolutely lovely and Tim has very welcoming to both of us – we had a great time, Tim’s a really interesting guy and good fun (thanks again Tim!).

In the morning, we had a bit of a wander around the farm – Jen got scared by some cows that mooed at her in what she deemed to be an aggressive manner! Then we headed to Havelock North for a spot of wine tasting – after the delights of Blenheim, we had high expectations, but were sadly disappointed by the wines on offer – the Chardonnays were nice, but the rest were mediocre. Nevertheless, we made up for it by finding a great cheese tasting place and a honey tasting place!

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_2042.jpg "Koru")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/1164683652_img_2042.jpg)So now we’re in Lake Taupo (well, obviously not in it – electricity and water are not good friends), we went for a walk to Huka Falls today – there’s a great little hot water spring that you can sit in on and it’s totally free – although I couldn’t convince Jen to try it! We’ll have a bit more of a look around tomorrow, then we’re stopping at Rotorua for a bit before heading to Raglan to see Nicky – joyful days!