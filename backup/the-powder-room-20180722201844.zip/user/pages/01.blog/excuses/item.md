---
# http://learn.getgrav.org/content/headers
title: Excuses&#8230;
slug: excuses
# menu: Excuses&#8230;
date: 30-09-2010
published: true
publish_date: 30-09-2010
# unpublish_date: 30-09-2010
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Uncategorized]
    tag: []
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

OK, so I’m still rubbish at updating my blog. Partly because I’m not sure what I’m doing with this anymore, I seem to have conflated work with my personal life, very mixed audiences; but also partly because I’ve been busy at work.  
 So I’m working out what to do and probably going to split off my work bits elsewhere.  
 Watch this space (hopefully not for too long!)