---
# http://learn.getgrav.org/content/headers
title: Home
slug: home
# menu: Home
date: 24-04-2007
published: true
publish_date: 24-04-2007
# unpublish_date: 24-04-2007
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [The Rat Race]
    tag: [lebenskrankheit,lebenskrankheit]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**24th April 2007, 18.01**  
*Sitting on the end of my bed in Sutton. Home.*

Wow. So San Francisco was cool, not as great as I was expecting, but we had a fun time, just hanging out (and walking far too much!). Then suddenly it was over and Jen and I went our separate ways to the same place(!?). The flight home was very surreal, after managing to get all our luggage (and it was a LOT!) onto planes, I failed to sleep for the 11 flying hours, being sandwiched against a window and a fat Indian man whose arms squished over the controls for the in-flight entertainment. Then circling in a holding pattern over London and the most impressive approach to Heathrow I’ve seen, dropping past the Millenium Dome and right the way over Central London. As we touched down over London’s grey skies (would it be anything else?), a tear breached my eyes at seeing familiar houses and cars and greeness. Mum and Dad were there to pick me up (although they had to wait for over an hour as my bags took forever!) and then cram everything into a Nissan Micra (you’d be surprised what will fit), before driving home.

Perhaps it was all too much for me, but it seemed very ordinary, very mundane. I’ve spent the time hovering between apathy and total bewilderment as to what to do with myself. Maybe it’s the jetlag, maybe it’s being on my own for the first time in ages, maybe it’s nothing. I’m looking forward to starting work, but I feel a little like I’m in limbo and waiting for the next phase. Trying to organise myself and unpack, but quite frankly feel lost – it all just doesn’t seem real, at the moment, everything I’ve done for the past year seems not have happened. Everything’s changed, but nothing’s changed. It’ll all be grand in the end, but thought I’d share my thoughts!