---
# http://learn.getgrav.org/content/headers
title: Heli Celi(bration)
slug: heli-celibration
# menu: Heli Celi(bration)
date: 06-08-2006
published: true
publish_date: 06-08-2006
# unpublish_date: 06-08-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,new zealand,snow,travel,instructing,new zealand,snow,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**6th August 2006, 18:00**  
*Alpine Resort – exhausted and happy*

![Pete and Claire looking mischevious](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/peteandclaire1.jpg "Pete and Claire looking mischevious")Despite last night’s celebrations, struggled my way out of bed and crawled to the bus for a day’s riding. Glad I did, cos it was well worth it and got to enjoy another perfect sunrise over TC.

I’ve been so lucky over the past few weeks to have so many moments of sheer pleasure and beauty. This place just blows me away – every morning we are treated to the most spectacular commute you could wish for, with a different range of colours spreading out over the horizon in the most perfect of sunrises. Even on the bad weather days, the cloud makes for a spectacular lightshow.

![Me looking out over TC](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/pensivemelookingoutattc.jpg "Me looking out over TC")Then we get 5 hours of training with some of the best snowboard trainers in the world and some of the most fun people to be around that I’ve ever had the priviledge to meet.

After all that, we get to come home to luxury apartments, maybe have a few drinks or just chill with mates and watch the sun set over a perfect day, safe in the knowledge that it’ll all start over again in the morning.

Yeah it’s hard work, mentally and physically challenging, exhausting at times and far from home, but a bad day on the slopes still beats a good day in the office hands down!