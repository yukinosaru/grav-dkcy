---
# http://learn.getgrav.org/content/headers
title: A tale of BASI
slug: a-tale-of-basi
# menu: A tale of BASI
date: 19-09-2006
published: true
publish_date: 19-09-2006
# unpublish_date: 19-09-2006
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Rookie Academy]
    tag: [instructing,snow,instructing,snow]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

**19th September 2006, 21.16**  
*At home, watching rubbish music on J2 having had a power nap.*

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/fireworksoverwanaka.jpg "Fireworks over Wanaka")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/fireworksoverwanaka.jpg) Been pretty slack at blog entries, partly due to techincal difficulties and partly due to being totally exhausted. So, three days left and I think it’s safe to say that I’ve been through every emotion I’ve got. It’s been a pretty intense time and I’ll be glad when it’s over – snow’s been terrible and the weather not much better.

Started buoyantly as a few things had dropped into place just before the exam started. But, by Wednesday, I was feeling totally exhausted and my knees were killing me. The weather and snow continued to get worse, which made it hard to keep spirits up. We had lots of video sessions and none of them particularly good. But I thought the latter half of the week would be better – we were due to cover carving – an area that I felt really confident on. However, on the day, the snow was really difficult (not that that’s an excuse) and I had an absolute shocker – scoring around 2/3 instead of the 5 I need to pass, so ended the week on a real bummer.

Spent the weekend working on a few things (despite barely being able to get out of bed) and Saturday was great – a bit of fresh snow and the whole day spent working on turns and riding bumps with Mike. Basically, needed to concentrate on closing off my turns and pedalling around the board.

[![](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/firepoi.jpg "Fire poi")](http://user47216.vs.easily.co.uk/wp-content/uploads/2008/12/firepoi.jpg)I decided to take Sunday off as I needed the rest, but spent most of Sunday wandering around in a daze and feeling really low on energy. Went out on Sunday night as it was the last night of Wanakafest – watched the rail jam and snapped away with my camera at the fire poi and fireworks displays. It was a good distraction and Monday was a much better day – got lots of real positive feedback on all the stuff I’ve been working on.

Which just about brings us up to date – today was the first day of our teaching assessments. I had to teach garlands to a group of unfit clients – it went well and I feel pretty good about the teaching side. Got one more lesson to give tomorrow – I’m doing it on aft-pressure (basically, pressing the back of the snowboard to get more grip) – something that I’ve only recently discovered but has really helped my riding.

So there we have it, my BASI so far, feeling totally exhausted and tired of being assessed continuously, only a few more days to go – just writing my lesson plan now, then will have a good sleep! Tomorrow is the last teach, then there will be two more days of riding assessment – a chance to redeem myself from last week’s performance.