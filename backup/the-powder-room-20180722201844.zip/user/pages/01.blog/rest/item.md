---
# http://learn.getgrav.org/content/headers
title: Rest!
slug: rest
# menu: Rest!
date: 08-11-2008
published: true
publish_date: 08-11-2008
# unpublish_date: 08-11-2008
# template: false
# theme: false
visible: true
summary:
    enabled: true
    format: short
    size: 128
taxonomy:
    migration-status: review
    category: [Itchy Feet]
    tag: [nepal,travel,nepal,travel]
author: admin
metadata:
    author: admin
#      description: Your page description goes here
#      keywords: HTML, CSS, XML, JavaScript
#      robots: noindex, nofollow
#      og:
#          title: The Rock
#          type: video.movie
#          url: http://www.imdb.com/title/tt0117500/
#          image: http://ia.media-imdb.com/images/rock.jpg
#  cache_enable: false
#  last_modified: true

---

Glorious lie-in before a gentle breakfast sitting in the garden. List of things to do, most which were sorted before we even left the hostel. General mooching about, then a last-minute splash about on Phewa Tal – sunset over the Annapurnas, fish splashing about, me doing my best Cornetto singing. Then out for dinnner, bought some travelly type clothes and ate steak at the Everest Steak House!

 
			#gallery-2 {
				margin: auto;
			}
			#gallery-2 .gallery-item {
				float: left;
				margin-top: 10px;
				text-align: center;
				width: 33%;
			}
			#gallery-2 img {
				border: 2px solid #cfcfcf;
			}
			#gallery-2 .gallery-caption {
				margin-left: 0;
			}
			/* see gallery_shortcode() in wp-includes/media.php */
		 [![](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)](http://www.dkcy.com/wp-content/uploads/2008/12/20081110_4682.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6897.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090430_6911.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_6996.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7000.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7003.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7009.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7010.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7011.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090507_7014.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090516_7373.jpg)  [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7538.jpg)   
 [![](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)](http://www.dkcy.com/wp-content/uploads/2009/06/20090521_7540.jpg)   